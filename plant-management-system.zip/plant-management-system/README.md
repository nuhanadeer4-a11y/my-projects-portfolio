# Thottam — Plant Management System

A complete React + Vite plant nursery management system, built around your
spec: Dashboard, Plant Management (with photos), Categories, Inventory/Stock,
Customer Management, Orders, Plant Care, Reports, and Profile — all priced
in **Sri Lankan Rupees (LKR)**, behind a mandatory login.

## Core rule implemented

> When an order is placed: send the confirmation by **email** if the customer
> gave one. If they didn't, send it by **SMS** to their phone number instead.

This logic lives in one place: `src/utils/notifications.js` →
`notifyCustomerOfOrder()`.

## Pages / Interfaces

| Page | Who sees it | What it does |
|---|---|---|
| **Home / About / Contact Us** | Everyone (no login needed) | Public marketing site with a "Login" call to action |
| **Login / Signup** | Everyone | Required before the shopping/management app loads |
| **Dashboard** | Admin | Total plants, categories, plants sold, low-stock count, sales trend, recent orders |
| **Plants** | Admin | Add / edit / delete plants — photo upload, category, price (LKR), stock, description |
| **Categories** | Admin | Add / edit / delete categories (Indoor, Outdoor, Flowering, Medicinal, Succulents, or your own) |
| **Inventory** | Admin | Add stock / reduce stock with a reason, low-stock warnings, full stock history log |
| **Customers** | Admin | Simple CRM — add / edit / delete customer records, see their order count |
| **Orders** | Admin sees all, Customer sees their own | Status timeline: Confirmed → Packed → Shipped → Delivered |
| **Reports** | Admin | Monthly sales chart, most-sold plants, low-stock report, full stock table |
| **Plant Care** | Admin | Watering, fertilizer, sunlight, temperature and care notes per plant |
| **Catalog / Cart / Checkout** | Customer | Browse, add to cart, pay, get notified |
| **Profile** | Everyone | Edit name/phone, change password, log out |

## Advanced features included

- **Login required for the whole app**, with Customer vs Admin (Nursery
  staff) roles controlling what's visible in the sidebar
- **Plant photo upload** — pick an image file and it's stored as the plant's
  photo (client-side, no server needed for the demo)
- **Checkout with a real payment step** — Card (live formatting, brand
  detection, expiry/CVV validation), UPI, or Cash on Delivery
- **Email → SMS fallback routing** for every order confirmation
- **Real browser desktop notifications** (Notification API) — click "Enable
  order alerts" in the header
- **Sales dashboard & reports** (Recharts: monthly line chart, best-sellers
  bar chart)
- **Stock history log** — every stock addition/reduction is timestamped with
  a reason
- **Low-stock alerts** on the Dashboard, Inventory, and Reports pages
- **Debounced live search** (250ms) across the catalog, with category filters
  that update automatically when you edit Categories
- **Global state via Context + useReducer**, persisted to `localStorage`
- **Dark mode** with CSS variable theming
- Fully responsive: sidebar nav on desktop, bottom tab bar on mobile

## Demo login

- Email: `demo@thottam.com`
- Password: `demo123`

(Or click "Fill demo admin credentials" on the login screen.) Anyone can also
sign up as a new Customer or Admin — accounts are stored only in your
browser's `localStorage`, there is no real backend.

## Getting started

```bash
npm install
npm run dev
```

Then open the printed local URL (usually `http://localhost:5173`).

To build for production:

```bash
npm run build
npm run preview
```

## Project structure

```
src/
  components/   All pages: Auth, Dashboard, Plants, Categories, Inventory,
                Customers, OrdersList, Reports, PlantCare, PlantCatalog,
                Cart, Checkout, PaymentForm, Profile, Sidebar, Header...
  context/      AppContext.jsx — plants, categories, cart, orders, stock
                history, customers, users, theme (all persisted)
  data/         Seed plants + categories
  utils/        notifications.js (email/SMS routing), payments.js (payment
                gateway), auth.js (login), currency.js (LKR formatting)
```

## Going live with real email, SMS, payments & login

Everything above works instantly with **zero setup** — no API keys, no
backend — because email, SMS, and card/UPI payments are all simulated, and
accounts live in the browser's `localStorage`. That's what makes this safe
to demo anywhere. For a real production nursery system:

### Real email (works entirely from the browser)

1. Create a free account at [EmailJS](https://www.emailjs.com/).
2. `npm install @emailjs/browser`
3. In `src/utils/notifications.js` → `sendEmail()`, replace the body with:
   ```js
   import emailjs from '@emailjs/browser'
   await emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID',
     { to_email: to, subject, message: body }, 'YOUR_PUBLIC_KEY')
   ```

### Real SMS (needs one small backend endpoint)

SMS providers (Twilio, MSG91, Dialog, Notify.lk for Sri Lanka) block direct
browser requests for security. Add one server route that calls your chosen
provider, then have `sendSMS()` in `notifications.js` call that route
instead of simulating.

### Real payments

`src/utils/payments.js` has full comments on wiring up Razorpay/PayHere/
Stripe: your backend creates an order, the frontend opens the provider's
checkout with that order ID, and your backend verifies the payment on a
webhook before marking the order paid.

### Real accounts

`src/utils/auth.js` and the `users` state in `AppContext.jsx` currently
store accounts in `localStorage` with a non-cryptographic hash — fine for a
demo, not for production. Swap in a real backend or a service like Supabase
Auth / Firebase Auth / Clerk, which hash passwords properly and issue secure
session tokens.

Nothing else in the app — the UI, the order flow, the email/SMS decision —
needs to change when you swap these in.
