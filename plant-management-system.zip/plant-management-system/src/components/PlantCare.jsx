import React, { useState } from 'react'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'
import { SunIcon, DropIcon, LeafIcon } from './icons.jsx'

export default function PlantCare() {
  const { plants } = useAppState()
  const dispatch = useAppDispatch()
  const [editingId, setEditingId] = useState(null)
  const [form, setForm] = useState({})

  function startEdit(plant) {
    setEditingId(plant.id)
    setForm({
      light: plant.light,
      water: plant.water,
      fertilizer: plant.fertilizer || '',
      temperature: plant.temperature || '',
      careInstructions: plant.careInstructions || '',
    })
  }

  function save(plant) {
    dispatch({ type: 'UPDATE_PLANT', plant: { ...plant, ...form } })
    setEditingId(null)
  }

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12 grid grid-cols-1 md:grid-cols-2 gap-4">
      {plants.map((p) => (
        <div key={p.id} className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-sm bg-forest/10 dark:bg-white/5 overflow-hidden shrink-0 flex items-center justify-center">
              {p.image ? (
                <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
              ) : (
                <LeafIcon className="w-4 h-4 text-[var(--text-muted)]" />
              )}
            </div>
            <div>
              <p className="font-display text-lg leading-tight">{p.name}</p>
              <p className="text-xs text-[var(--text-muted)]">{p.category}</p>
            </div>
          </div>

          {editingId === p.id ? (
            <div className="space-y-2">
              <LabeledInput label="Sunlight" value={form.light} onChange={(v) => setForm({ ...form, light: v })} />
              <LabeledInput label="Watering" value={form.water} onChange={(v) => setForm({ ...form, water: v })} />
              <LabeledInput label="Fertilizer" value={form.fertilizer} onChange={(v) => setForm({ ...form, fertilizer: v })} />
              <LabeledInput label="Temperature" value={form.temperature} onChange={(v) => setForm({ ...form, temperature: v })} />
              <div>
                <label className="text-xs text-[var(--text-muted)] block mb-1">Care instructions</label>
                <textarea
                  value={form.careInstructions}
                  onChange={(e) => setForm({ ...form, careInstructions: e.target.value })}
                  rows={2}
                  className="focus-ring w-full px-2 py-1.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
                />
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => save(p)}
                  className="focus-ring flex-1 py-2 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark text-xs font-medium"
                >
                  Save
                </button>
                <button
                  onClick={() => setEditingId(null)}
                  className="focus-ring px-3 py-2 rounded-sm border border-[var(--border)] text-xs"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-2 text-xs text-[var(--text-muted)] mb-3">
                <span className="flex items-center gap-1"><SunIcon className="w-3.5 h-3.5" /> {p.light}</span>
                <span className="flex items-center gap-1"><DropIcon className="w-3.5 h-3.5" /> {p.water}</span>
                <span>🌡 {p.temperature || '—'}</span>
                <span>🌿 {p.fertilizer || '—'}</span>
              </div>
              {p.careInstructions && (
                <p className="text-sm text-[var(--text-muted)] mb-3 leading-relaxed">{p.careInstructions}</p>
              )}
              <button onClick={() => startEdit(p)} className="focus-ring text-xs text-clay hover:underline">
                Edit care details
              </button>
            </>
          )}
        </div>
      ))}
    </div>
  )
}

function LabeledInput({ label, value, onChange }) {
  return (
    <div>
      <label className="text-xs text-[var(--text-muted)] block mb-1">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="focus-ring w-full px-2 py-1.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
      />
    </div>
  )
}
