import React from 'react'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'
import { BoxIcon, MailIcon, PhoneIcon } from './icons.jsx'
import { formatLKR } from '../utils/currency.js'

const STATUSES = ['Confirmed', 'Packed', 'Shipped', 'Delivered']

function StatusStepper({ status, orderId, dispatch, editable }) {
  const currentIndex = STATUSES.indexOf(status)
  return (
    <div className="flex items-center gap-1 mt-3">
      {STATUSES.map((s, i) => {
        const reached = i <= currentIndex
        const pill = (
          <span
            className={`text-[10px] uppercase tracking-wide px-2 py-1 rounded-full border transition-colors ${
              reached
                ? 'bg-forest text-linen border-forest dark:bg-sage-light dark:text-forest-dark dark:border-sage-light'
                : 'border-[var(--border)] text-[var(--text-muted)]'
            }`}
          >
            {s}
          </span>
        )
        return (
          <React.Fragment key={s}>
            {editable ? (
              <button
                onClick={() => dispatch({ type: 'UPDATE_ORDER_STATUS', id: orderId, status: s })}
                className="focus-ring"
              >
                {pill}
              </button>
            ) : (
              pill
            )}
            {i < STATUSES.length - 1 && (
              <div className={`h-px w-4 ${reached ? 'bg-forest dark:bg-sage-light' : 'bg-[var(--border)]'}`} />
            )}
          </React.Fragment>
        )
      })}
    </div>
  )
}

export default function OrdersList() {
  const { orders, currentUser } = useAppState()
  const dispatch = useAppDispatch()

  const visibleOrders =
    currentUser?.role === 'admin'
      ? orders
      : orders.filter((o) => o.userId === currentUser?.id)

  if (visibleOrders.length === 0) {
    return (
      <div className="px-6 md:px-10 pb-24 md:pb-12">
        <div className="text-center py-20 text-[var(--text-muted)] border border-dashed border-[var(--border)] rounded-sm">
          <BoxIcon className="w-8 h-8 mx-auto mb-3 opacity-50" />
          <p className="font-display text-xl mb-1">No orders yet</p>
          <p className="text-sm">Orders placed from the catalog will show up here.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12 space-y-4">
      {visibleOrders.map((order) => (
        <div key={order.id} className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div>
              <p className="font-display text-lg">{order.id}</p>
              <p className="text-xs text-[var(--text-muted)]">
                {order.customer.name} · {new Date(order.placedAt).toLocaleString('en-IN')}
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[var(--text-muted)]">
              {order.customer.email ? <MailIcon className="w-3.5 h-3.5" /> : <PhoneIcon className="w-3.5 h-3.5" />}
              {order.customer.email || order.customer.phone}
            </div>
          </div>

          <p className="text-sm text-[var(--text-muted)] mt-2">
            {order.items.map((i) => `${i.name} ×${i.qty}`).join(', ')}
          </p>

          <div className="flex items-center justify-between mt-3">
            <span className="font-display text-lg text-forest dark:text-sage-light">{formatLKR(order.total)}</span>
          </div>

          <StatusStepper
            status={order.status}
            orderId={order.id}
            dispatch={dispatch}
            editable={currentUser?.role === 'admin'}
          />
        </div>
      ))}
    </div>
  )
}
