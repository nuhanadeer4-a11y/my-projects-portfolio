import React, { useEffect, useMemo, useState } from 'react'
import PlantCard from './PlantCard.jsx'
import { useAppState } from '../context/AppContext.jsx'

// Advanced feature: debounced search so filtering doesn't run on every
// keystroke, only after the user pauses typing for 250ms.
function useDebouncedValue(value, delayMs) {
  const [debounced, setDebounced] = useState(value)
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delayMs)
    return () => clearTimeout(t)
  }, [value, delayMs])
  return debounced
}

export default function PlantCatalog() {
  const { plants, categories } = useAppState()
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('All')
  const debouncedQuery = useDebouncedValue(query, 250)
  const categoryNames = ['All', ...categories.map((c) => c.name)]

  const filtered = useMemo(() => {
    return plants.filter((p) => {
      const matchesCategory = category === 'All' || p.category === category
      const q = debouncedQuery.trim().toLowerCase()
      const matchesQuery =
        q.length === 0 ||
        p.name.toLowerCase().includes(q) ||
        p.tamilName.includes(q)
      return matchesCategory && matchesQuery
    })
  }, [plants, category, debouncedQuery])

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12">
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search plants... (e.g. tulsi, snake)"
          className="focus-ring flex-1 px-4 py-2.5 rounded-sm border border-[var(--border)] bg-[var(--surface)] text-sm placeholder:text-[var(--text-muted)]"
        />
        <div className="flex gap-2 overflow-x-auto">
          {categoryNames.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`focus-ring shrink-0 text-xs px-3 py-2 rounded-full border transition-colors ${
                category === c
                  ? 'bg-clay text-linen border-clay'
                  : 'border-[var(--border)] text-[var(--text-muted)] hover:border-clay'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-20 text-[var(--text-muted)]">
          <p className="font-display text-xl mb-1">No plants match that search</p>
          <p className="text-sm">Try a different name or clear the category filter.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((plant) => (
            <PlantCard key={plant.id} plant={plant} />
          ))}
        </div>
      )}
    </div>
  )
}
