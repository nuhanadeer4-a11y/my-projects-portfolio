import React, { useState } from 'react'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'
import { hashPassword, isValidEmail, isValidPhone } from '../utils/auth.js'
import { LeafIcon, UserIcon, LockIcon, EyeIcon, EyeOffIcon } from './icons.jsx'

export default function Auth({ onSuccess }) {
  const { users } = useAppState()
  const dispatch = useAppDispatch()
  const [mode, setMode] = useState('login') // login | signup
  const [showPassword, setShowPassword] = useState(false)
  const [errors, setErrors] = useState({})
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    role: 'customer',
  })

  function handleLogin(e) {
    e.preventDefault()
    const next = {}
    if (!form.email.trim()) next.email = 'Enter your email'
    if (!form.password) next.password = 'Enter your password'
    if (Object.keys(next).length) return setErrors(next)

    const user = users.find(
      (u) => u.email.toLowerCase() === form.email.trim().toLowerCase()
    )
    if (!user || user.passwordHash !== hashPassword(form.password)) {
      setErrors({ form: 'Email or password is incorrect' })
      return
    }
    setErrors({})
    dispatch({ type: 'LOGIN', user })
    onSuccess?.()
  }

  function handleSignup(e) {
    e.preventDefault()
    const next = {}
    if (!form.name.trim()) next.name = 'Enter your name'
    if (!isValidEmail(form.email)) next.email = 'Enter a valid email'
    if (!isValidPhone(form.phone)) next.phone = 'Enter a 10-digit phone number'
    if (form.password.length < 6) next.password = 'At least 6 characters'
    if (users.some((u) => u.email.toLowerCase() === form.email.trim().toLowerCase())) {
      next.email = 'An account with this email already exists'
    }
    if (Object.keys(next).length) return setErrors(next)

    const user = {
      id: 'USR-' + Date.now().toString().slice(-6),
      name: form.name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      role: form.role,
      passwordHash: hashPassword(form.password),
      joinedAt: new Date().toISOString(),
    }
    setErrors({})
    dispatch({ type: 'SIGNUP', user })
    onSuccess?.()
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--bg)] px-6">
      <div className="w-full max-w-sm">
        <div className="flex items-center gap-2 justify-center mb-8">
          <LeafIcon className="w-7 h-7 text-forest dark:text-sage-light" />
          <span className="font-display text-2xl italic text-forest dark:text-sage-light">
            Thottam
          </span>
        </div>

        <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-6 stamp-in">
          <div className="flex gap-1 mb-6 border-b border-[var(--border)]">
            <button
              onClick={() => { setMode('login'); setErrors({}) }}
              className={`focus-ring flex-1 pb-3 text-sm font-medium border-b-2 -mb-px transition-colors ${
                mode === 'login' ? 'border-clay text-clay' : 'border-transparent text-[var(--text-muted)]'
              }`}
            >
              Log in
            </button>
            <button
              onClick={() => { setMode('signup'); setErrors({}) }}
              className={`focus-ring flex-1 pb-3 text-sm font-medium border-b-2 -mb-px transition-colors ${
                mode === 'signup' ? 'border-clay text-clay' : 'border-transparent text-[var(--text-muted)]'
              }`}
            >
              Sign up
            </button>
          </div>

          {errors.form && (
            <p className="text-xs text-rose bg-rose/10 border border-rose/30 rounded-sm px-3 py-2 mb-4">
              {errors.form}
            </p>
          )}

          {mode === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-3">
              <Field
                icon={<UserIcon className="w-4 h-4" />}
                placeholder="Email address"
                value={form.email}
                onChange={(v) => setForm({ ...form, email: v })}
                error={errors.email}
              />
              <PasswordField
                value={form.password}
                onChange={(v) => setForm({ ...form, password: v })}
                error={errors.password}
                show={showPassword}
                setShow={setShowPassword}
              />
              <button
                type="submit"
                className="focus-ring w-full py-2.5 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors mt-2"
              >
                Log in
              </button>
              <p className="text-xs text-[var(--text-muted)] text-center pt-1">
                No account yet? Try the demo admin below or sign up.
              </p>
              <button
                type="button"
                onClick={() => {
                  setForm({ ...form, email: 'demo@thottam.com', password: 'demo123' })
                }}
                className="focus-ring w-full text-xs text-clay hover:underline"
              >
                Fill demo admin credentials
              </button>
            </form>
          ) : (
            <form onSubmit={handleSignup} className="space-y-3">
              <Field
                icon={<UserIcon className="w-4 h-4" />}
                placeholder="Full name"
                value={form.name}
                onChange={(v) => setForm({ ...form, name: v })}
                error={errors.name}
              />
              <Field
                placeholder="Email address"
                value={form.email}
                onChange={(v) => setForm({ ...form, email: v })}
                error={errors.email}
              />
              <Field
                placeholder="Phone number"
                value={form.phone}
                onChange={(v) => setForm({ ...form, phone: v })}
                error={errors.phone}
              />
              <PasswordField
                value={form.password}
                onChange={(v) => setForm({ ...form, password: v })}
                error={errors.password}
                show={showPassword}
                setShow={setShowPassword}
              />
              <div>
                <label className="text-xs text-[var(--text-muted)] block mb-1.5">I am signing up as</label>
                <div className="grid grid-cols-2 gap-2">
                  {['customer', 'admin'].map((r) => (
                    <button
                      type="button"
                      key={r}
                      onClick={() => setForm({ ...form, role: r })}
                      className={`focus-ring py-2 rounded-sm border text-sm capitalize transition-colors ${
                        form.role === r
                          ? 'bg-clay text-linen border-clay'
                          : 'border-[var(--border)] text-[var(--text-muted)]'
                      }`}
                    >
                      {r === 'admin' ? 'Nursery staff' : 'Customer'}
                    </button>
                  ))}
                </div>
              </div>
              <button
                type="submit"
                className="focus-ring w-full py-2.5 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors mt-2"
              >
                Create account
              </button>
            </form>
          )}
        </div>

        <p className="text-center text-xs text-[var(--text-muted)] mt-4">
          Demo app — accounts are stored only in this browser.
        </p>
      </div>
    </div>
  )
}

function Field({ icon, placeholder, value, onChange, error }) {
  return (
    <div>
      <div className="relative">
        {icon && (
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]">
            {icon}
          </span>
        )}
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={`focus-ring w-full py-2.5 rounded-sm border border-[var(--border)] bg-transparent text-sm ${icon ? 'pl-9 pr-3' : 'px-3'}`}
        />
      </div>
      {error && <p className="text-xs text-rose mt-1">{error}</p>}
    </div>
  )
}

function PasswordField({ value, onChange, error, show, setShow }) {
  return (
    <div>
      <div className="relative">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]">
          <LockIcon className="w-4 h-4" />
        </span>
        <input
          type={show ? 'text' : 'password'}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Password"
          className="focus-ring w-full pl-9 pr-9 py-2.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
        />
        <button
          type="button"
          onClick={() => setShow(!show)}
          className="focus-ring absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"
        >
          {show ? <EyeOffIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
        </button>
      </div>
      {error && <p className="text-xs text-rose mt-1">{error}</p>}
    </div>
  )
}
