import React from 'react'
import {
  LeafIcon, CartIcon, BoxIcon, ChartIcon, PotIcon, UserIcon,
} from './icons.jsx'
import { useAppState } from '../context/AppContext.jsx'

const ADMIN_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: ChartIcon },
  { id: 'plants', label: 'Plants', icon: LeafIcon },
  { id: 'categories', label: 'Categories', icon: PotIcon },
  { id: 'inventory', label: 'Inventory', icon: BoxIcon },
  { id: 'customers', label: 'Customers', icon: UserIcon },
  { id: 'orders', label: 'Orders', icon: BoxIcon },
  { id: 'reports', label: 'Reports', icon: ChartIcon },
  { id: 'plant-care', label: 'Plant Care', icon: LeafIcon },
]

const CUSTOMER_ITEMS = [
  { id: 'catalog', label: 'Catalog', icon: LeafIcon },
  { id: 'cart', label: 'Cart', icon: CartIcon },
  { id: 'orders', label: 'My Orders', icon: BoxIcon },
]

export default function Sidebar({ view, setView }) {
  const { cart, currentUser } = useAppState()
  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0)
  const isAdmin = currentUser?.role === 'admin'
  const items = isAdmin ? ADMIN_ITEMS : CUSTOMER_ITEMS

  return (
    <aside className="hidden md:flex md:flex-col w-56 shrink-0 border-r border-[var(--border)] px-4 py-6 gap-1">
      <div className="flex items-center gap-2 px-2 mb-8">
        <LeafIcon className="w-6 h-6 text-forest dark:text-sage-light" />
        <span className="font-display text-xl italic tracking-tight text-forest dark:text-sage-light">
          Thottam
        </span>
      </div>

      {items.map((item) => {
        const Icon = item.icon
        const active = view === item.id
        return (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={`focus-ring relative flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
              active
                ? 'bg-forest text-linen dark:bg-sage-light dark:text-forest-dark'
                : 'text-charcoal/70 dark:text-[var(--text-muted)] hover:bg-forest/5 dark:hover:bg-white/5'
            }`}
          >
            <Icon className="w-4 h-4" />
            {item.label}
            {item.id === 'cart' && cartCount > 0 && (
              <span className="ml-auto text-xs bg-clay text-linen rounded-full min-w-[1.25rem] h-5 px-1 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
        )
      })}

      <div className="leaf-divider my-4" />
      <button
        onClick={() => setView('profile')}
        className={`focus-ring flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
          view === 'profile'
            ? 'bg-forest text-linen dark:bg-sage-light dark:text-forest-dark'
            : 'text-charcoal/70 dark:text-[var(--text-muted)] hover:bg-forest/5 dark:hover:bg-white/5'
        }`}
      >
        <UserIcon className="w-4 h-4" /> Profile
      </button>
      <p className="px-3 pt-3 text-xs text-[var(--text-muted)] leading-relaxed">
        Every order confirms itself — by email when we have one, by SMS when we don't.
      </p>
    </aside>
  )
}
