import React, { useState } from 'react'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'
import Checkout from './Checkout.jsx'
import { CartIcon } from './icons.jsx'
import { formatLKR } from '../utils/currency.js'

export default function Cart() {
  const { cart } = useAppState()
  const dispatch = useAppDispatch()
  const [checkingOut, setCheckingOut] = useState(false)

  const total = cart.reduce((sum, i) => sum + i.qty * i.price, 0)

  if (cart.length === 0 && !checkingOut) {
    return (
      <div className="px-6 md:px-10 pb-24 md:pb-12">
        <div className="text-center py-20 text-[var(--text-muted)] border border-dashed border-[var(--border)] rounded-sm">
          <CartIcon className="w-8 h-8 mx-auto mb-3 opacity-50" />
          <p className="font-display text-xl mb-1">Your cart is empty</p>
          <p className="text-sm">Add a few plants from the catalog to get started.</p>
        </div>
      </div>
    )
  }

  if (checkingOut) {
    return <Checkout onBack={() => setCheckingOut(false)} />
  }

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12 max-w-2xl">
      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] divide-y divide-[var(--border)]">
        {cart.map((item) => (
          <div key={item.id} className="flex items-center gap-4 p-4">
            <div className="flex-1">
              <p className="font-medium">{item.name}</p>
              <p className="text-xs text-[var(--text-muted)]">{formatLKR(item.price)} each</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => dispatch({ type: 'DECREASE_QTY', id: item.id })}
                className="focus-ring w-7 h-7 rounded-full border border-[var(--border)] flex items-center justify-center hover:border-clay"
              >
                −
              </button>
              <span className="w-5 text-center text-sm">{item.qty}</span>
              <button
                onClick={() => dispatch({ type: 'ADD_TO_CART', plant: item })}
                className="focus-ring w-7 h-7 rounded-full border border-[var(--border)] flex items-center justify-center hover:border-clay"
              >
                +
              </button>
            </div>
            <p className="w-16 text-right text-sm font-medium">{formatLKR(item.qty * item.price)}</p>
            <button
              onClick={() => dispatch({ type: 'REMOVE_FROM_CART', id: item.id })}
              className="focus-ring text-xs text-rose/70 hover:text-rose"
            >
              Remove
            </button>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between mt-6 mb-4">
        <span className="text-[var(--text-muted)]">Total</span>
        <span className="font-display text-2xl text-forest dark:text-sage-light">{formatLKR(total)}</span>
      </div>

      <button
        onClick={() => setCheckingOut(true)}
        className="focus-ring w-full py-3 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors"
      >
        Proceed to checkout
      </button>
    </div>
  )
}
