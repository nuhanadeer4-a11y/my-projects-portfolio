import React, { useState } from 'react'
import {
  formatCardNumber, formatExpiry, validateCard, isValidUpiId,
  detectCardBrand, processCardPayment, processUpiPayment, processCashOnDelivery,
} from '../utils/payments.js'
import { CardIcon, UpiIcon, CashIcon, ShieldIcon, LockIcon } from './icons.jsx'
import { formatLKR } from '../utils/currency.js'

const METHODS = [
  { id: 'card', label: 'Card', icon: CardIcon },
  { id: 'upi', label: 'UPI', icon: UpiIcon },
  { id: 'cod', label: 'Cash on delivery', icon: CashIcon },
]

export default function PaymentForm({ amount, onPaid, onBack }) {
  const [method, setMethod] = useState('card')
  const [processing, setProcessing] = useState(false)
  const [errors, setErrors] = useState({})
  const [card, setCard] = useState({ number: '', expiry: '', cvv: '', name: '' })
  const [upiId, setUpiId] = useState('')

  async function handlePay(e) {
    e.preventDefault()

    if (method === 'card') {
      const cardErrors = validateCard(card)
      if (Object.keys(cardErrors).length) return setErrors(cardErrors)
      setErrors({})
      setProcessing(true)
      const result = await processCardPayment({ amount, card })
      setProcessing(false)
      onPaid(result)
      return
    }

    if (method === 'upi') {
      if (!isValidUpiId(upiId)) return setErrors({ upiId: 'Enter a valid UPI ID, e.g. name@upi' })
      setErrors({})
      setProcessing(true)
      const result = await processUpiPayment({ amount, upiId })
      setProcessing(false)
      onPaid(result)
      return
    }

    setProcessing(true)
    const result = await processCashOnDelivery({ amount })
    setProcessing(false)
    onPaid(result)
  }

  if (processing) {
    return (
      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-10 text-center">
        <div className="w-10 h-10 mx-auto mb-4 rounded-full border-2 border-clay border-t-transparent animate-spin" />
        <p className="font-display text-lg">Processing payment…</p>
        <p className="text-sm text-[var(--text-muted)] mt-1">Please don't close this window</p>
      </div>
    )
  }

  return (
    <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-6">
      <button onClick={onBack} className="focus-ring text-sm text-[var(--text-muted)] hover:text-clay mb-4">
        ← Back
      </button>

      <div className="flex items-center justify-between mb-5">
        <h2 className="font-display text-xl">Payment</h2>
        <span className="font-display text-xl text-forest dark:text-sage-light">{formatLKR(amount)}</span>
      </div>

      <div className="grid grid-cols-3 gap-2 mb-5">
        {METHODS.map((m) => {
          const Icon = m.icon
          return (
            <button
              key={m.id}
              type="button"
              onClick={() => { setMethod(m.id); setErrors({}) }}
              className={`focus-ring flex flex-col items-center gap-1.5 py-3 rounded-sm border text-xs transition-colors ${
                method === m.id
                  ? 'border-clay bg-clay/5 text-clay'
                  : 'border-[var(--border)] text-[var(--text-muted)]'
              }`}
            >
              <Icon className="w-4 h-4" />
              {m.label}
            </button>
          )
        })}
      </div>

      <form onSubmit={handlePay} className="space-y-3">
        {method === 'card' && (
          <>
            <div>
              <div className="relative">
                <input
                  value={card.number}
                  onChange={(e) => setCard({ ...card, number: formatCardNumber(e.target.value) })}
                  placeholder="Card number"
                  inputMode="numeric"
                  className="focus-ring w-full px-3 py-2.5 pr-16 rounded-sm border border-[var(--border)] bg-transparent text-sm"
                />
                {card.number && (
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[var(--text-muted)]">
                    {detectCardBrand(card.number)}
                  </span>
                )}
              </div>
              {errors.number && <p className="text-xs text-rose mt-1">{errors.number}</p>}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <input
                  value={card.expiry}
                  onChange={(e) => setCard({ ...card, expiry: formatExpiry(e.target.value) })}
                  placeholder="MM/YY"
                  inputMode="numeric"
                  className="focus-ring w-full px-3 py-2.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
                />
                {errors.expiry && <p className="text-xs text-rose mt-1">{errors.expiry}</p>}
              </div>
              <div>
                <input
                  value={card.cvv}
                  onChange={(e) => setCard({ ...card, cvv: e.target.value.replace(/\D/g, '').slice(0, 4) })}
                  placeholder="CVV"
                  inputMode="numeric"
                  type="password"
                  className="focus-ring w-full px-3 py-2.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
                />
                {errors.cvv && <p className="text-xs text-rose mt-1">{errors.cvv}</p>}
              </div>
            </div>
            <div>
              <input
                value={card.name}
                onChange={(e) => setCard({ ...card, name: e.target.value })}
                placeholder="Name on card"
                className="focus-ring w-full px-3 py-2.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
              />
              {errors.name && <p className="text-xs text-rose mt-1">{errors.name}</p>}
            </div>
          </>
        )}

        {method === 'upi' && (
          <div>
            <input
              value={upiId}
              onChange={(e) => setUpiId(e.target.value)}
              placeholder="yourname@upi"
              className="focus-ring w-full px-3 py-2.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
            />
            {errors.upiId && <p className="text-xs text-rose mt-1">{errors.upiId}</p>}
          </div>
        )}

        {method === 'cod' && (
          <p className="text-sm text-[var(--text-muted)] border border-[var(--border)] rounded-sm p-3">
            Pay {formatLKR(amount)} in cash when your plants are delivered.
          </p>
        )}

        <button
          type="submit"
          className="focus-ring w-full py-3 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors mt-2"
        >
          {method === 'cod' ? 'Confirm order' : `Pay ${formatLKR(amount)}`}
        </button>

        <p className="flex items-center justify-center gap-1.5 text-xs text-[var(--text-muted)] pt-1">
          <ShieldIcon className="w-3.5 h-3.5" /> Simulated payment for this demo — no real money is charged
        </p>
      </form>
    </div>
  )
}
