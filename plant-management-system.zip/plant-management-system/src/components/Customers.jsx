import React, { useState } from 'react'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'
import { isValidEmail, isValidPhone } from '../utils/auth.js'

const emptyForm = { name: '', email: '', phone: '', address: '' }

export default function Customers() {
  const { customers, orders } = useAppState()
  const dispatch = useAppDispatch()
  const [form, setForm] = useState(emptyForm)
  const [errors, setErrors] = useState({})
  const [editingId, setEditingId] = useState(null)

  function resetForm() {
    setForm(emptyForm)
    setEditingId(null)
    setErrors({})
  }

  function handleSubmit(e) {
    e.preventDefault()
    const next = {}
    if (!form.name.trim()) next.name = 'Name required'
    if (form.email && !isValidEmail(form.email)) next.email = 'Invalid email'
    if (form.phone && !isValidPhone(form.phone)) next.phone = '10-digit phone required'
    if (Object.keys(next).length) return setErrors(next)

    const customer = {
      id: editingId || 'CUS-' + Date.now().toString().slice(-6),
      name: form.name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      address: form.address.trim(),
      addedAt: editingId ? undefined : new Date().toISOString(),
    }
    dispatch({ type: editingId ? 'UPDATE_CUSTOMER' : 'ADD_CUSTOMER', customer })
    resetForm()
  }

  function handleEdit(c) {
    setForm({ name: c.name, email: c.email, phone: c.phone, address: c.address })
    setEditingId(c.id)
  }

  function orderCountFor(customer) {
    return orders.filter(
      (o) => o.customer.email === customer.email || o.customer.phone === customer.phone
    ).length
  }

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12 grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-6">
      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] overflow-hidden">
        {customers.length === 0 ? (
          <div className="text-center py-16 text-[var(--text-muted)]">
            <p className="font-display text-lg mb-1">No customers added yet</p>
            <p className="text-sm">Add walk-in or phone customers using the form.</p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs uppercase tracking-wide text-[var(--text-muted)] border-b border-[var(--border)]">
                <th className="p-3">Name</th>
                <th className="p-3">Contact</th>
                <th className="p-3">Orders</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {customers.map((c) => (
                <tr key={c.id} className="border-b border-[var(--border)] last:border-0">
                  <td className="p-3 font-medium">{c.name}</td>
                  <td className="p-3 text-[var(--text-muted)]">{c.email || c.phone || '—'}</td>
                  <td className="p-3">{orderCountFor(c)}</td>
                  <td className="p-3 text-right whitespace-nowrap">
                    <button onClick={() => handleEdit(c)} className="focus-ring text-xs text-clay hover:underline mr-3">
                      Edit
                    </button>
                    <button
                      onClick={() => dispatch({ type: 'DELETE_CUSTOMER', id: c.id })}
                      className="focus-ring text-xs text-rose/70 hover:text-rose hover:underline"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <form onSubmit={handleSubmit} className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5 h-fit space-y-3 sticky top-6">
        <h3 className="font-display text-lg mb-1">{editingId ? 'Edit customer' : 'Add customer'}</h3>
        <div>
          <input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="Full name"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
          {errors.name && <p className="text-xs text-rose mt-1">{errors.name}</p>}
        </div>
        <div>
          <input
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            placeholder="Email (optional)"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
          {errors.email && <p className="text-xs text-rose mt-1">{errors.email}</p>}
        </div>
        <div>
          <input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            placeholder="Phone (optional)"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
          {errors.phone && <p className="text-xs text-rose mt-1">{errors.phone}</p>}
        </div>
        <textarea
          value={form.address}
          onChange={(e) => setForm({ ...form, address: e.target.value })}
          placeholder="Address"
          rows={2}
          className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
        />
        <div className="flex gap-2 pt-1">
          <button
            type="submit"
            className="focus-ring flex-1 py-2.5 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark text-sm font-medium"
          >
            {editingId ? 'Save changes' : 'Add customer'}
          </button>
          {editingId && (
            <button type="button" onClick={resetForm} className="focus-ring px-4 py-2.5 rounded-sm border border-[var(--border)] text-sm">
              Cancel
            </button>
          )}
        </div>
      </form>
    </div>
  )
}
