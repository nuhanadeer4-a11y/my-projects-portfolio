import React from 'react'

// A deterministic, locally-rendered botanical illustration used whenever a
// plant has no photo (or its photo URL fails to load). Because it's plain
// inline SVG — no network request — it always renders, on any connection.
const PALETTE = [
  { bg: '#1F3D2B', fg: '#F7F5EF' }, // forest
  { bg: '#B5622E', fg: '#F7F5EF' }, // clay
  { bg: '#8FA787', fg: '#122318' }, // sage
  { bg: '#C99A3C', fg: '#122318' }, // amber
  { bg: '#A6413A', fg: '#F7F5EF' }, // rose
]

function pickPalette(seed) {
  let hash = 0
  for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) >>> 0
  return PALETTE[hash % PALETTE.length]
}

export default function PlantArt({ name = '', className = 'w-full h-full' }) {
  const { bg, fg } = pickPalette(name || 'plant')

  return (
    <svg viewBox="0 0 200 160" className={className} preserveAspectRatio="xMidYMid slice">
      <rect width="200" height="160" fill={bg} />
      {/* Pot */}
      <path d="M78 118 H122 L116 145 H84 Z" fill={fg} opacity="0.9" />
      <rect x="74" y="112" width="52" height="8" rx="2" fill={fg} opacity="0.9" />
      {/* Leaves */}
      <path d="M100 112 C 100 80 70 70 55 55 C 78 52 100 62 100 90 Z" fill={fg} opacity="0.85" />
      <path d="M100 112 C 100 78 132 68 148 52 C 124 50 100 60 100 88 Z" fill={fg} opacity="0.85" />
      <path d="M100 112 C 100 70 100 55 100 35 C 88 55 92 85 100 100 Z" fill={fg} opacity="0.95" />
    </svg>
  )
}
