import React from 'react'
import { LeafIcon, CartIcon, BoxIcon, ChartIcon, PotIcon, UserIcon } from './icons.jsx'
import { useAppState } from '../context/AppContext.jsx'

const ADMIN_ITEMS = [
  { id: 'dashboard', label: 'Home', icon: ChartIcon },
  { id: 'plants', label: 'Plants', icon: LeafIcon },
  { id: 'inventory', label: 'Stock', icon: BoxIcon },
  { id: 'orders', label: 'Orders', icon: PotIcon },
  { id: 'profile', label: 'Profile', icon: UserIcon },
]

const CUSTOMER_ITEMS = [
  { id: 'catalog', label: 'Catalog', icon: LeafIcon },
  { id: 'cart', label: 'Cart', icon: CartIcon },
  { id: 'orders', label: 'Orders', icon: BoxIcon },
  { id: 'profile', label: 'Profile', icon: UserIcon },
]

export default function MobileNav({ view, setView }) {
  const { cart, currentUser } = useAppState()
  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0)
  const isAdmin = currentUser?.role === 'admin'
  const items = isAdmin ? ADMIN_ITEMS : CUSTOMER_ITEMS

  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 bg-[var(--surface)] border-t border-[var(--border)] flex justify-around py-2 z-30">
      {items.map((item) => {
        const Icon = item.icon
        const active = view === item.id
        return (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={`focus-ring relative flex flex-col items-center gap-0.5 px-3 py-1 rounded-md text-[10px] font-medium ${
              active ? 'text-clay' : 'text-[var(--text-muted)]'
            }`}
          >
            <Icon className="w-5 h-5" />
            {item.label}
            {item.id === 'cart' && cartCount > 0 && (
              <span className="absolute -top-0.5 right-1 text-[9px] bg-clay text-linen rounded-full w-4 h-4 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
        )
      })}
    </nav>
  )
}
