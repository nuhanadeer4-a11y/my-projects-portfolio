import React from 'react'
import { LeafIcon, SunIcon, ShieldIcon, UserIcon } from './icons.jsx'

export default function About({ setView }) {
  return (
    <div>
      <section className="border-b border-[var(--border)]">
        <div className="max-w-4xl mx-auto px-6 py-16 text-center">
          <span className="text-xs uppercase tracking-widest text-clay">About us</span>
          <h1 className="font-display text-3xl md:text-4xl text-forest dark:text-sage-light mt-3 mb-4">
            Grown with care, since day one
          </h1>
          <p className="text-[var(--text-muted)] leading-relaxed max-w-2xl mx-auto">
            Thottam started as a small courtyard nursery with a simple idea:
            every home deserves a little green, and every plant deserves
            someone who knows how to care for it. Today we grow, pack, and
            deliver plants across Sri Lanka — still with the same care we
            started with.
          </p>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-6 py-14 grid grid-cols-1 md:grid-cols-3 gap-6">
        <AboutCard icon={<LeafIcon className="w-5 h-5" />} title="Our mission" text="Make it easy for anyone to bring healthy plants home, with clear guidance on how to keep them thriving." />
        <AboutCard icon={<SunIcon className="w-5 h-5" />} title="How we grow" text="Every plant is raised in our own nursery beds before it's ready for your home — no shortcuts, no imports of convenience." />
        <AboutCard icon={<ShieldIcon className="w-5 h-5" />} title="Our promise" text="If a plant doesn't reach you healthy, we make it right. Your order confirmation and delivery updates come straight from us." />
      </section>

      <section className="border-t border-[var(--border)] bg-forest/5 dark:bg-white/5">
        <div className="max-w-4xl mx-auto px-6 py-14">
          <h2 className="font-display text-2xl text-forest dark:text-sage-light mb-6 text-center">Meet the team</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { name: 'Kumari Perera', role: 'Founder & Head Grower' },
              { name: 'Nuha Rasheed', role: 'Operations' },
              { name: 'Ashan Silva', role: 'Customer Care' },
            ].map((person) => (
              <div key={person.name} className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5 text-center">
                <div className="w-12 h-12 rounded-full bg-forest text-linen dark:bg-sage-light dark:text-forest-dark flex items-center justify-center mx-auto mb-3">
                  <UserIcon className="w-5 h-5" />
                </div>
                <p className="font-medium text-sm">{person.name}</p>
                <p className="text-xs text-[var(--text-muted)]">{person.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-6 py-14 text-center">
        <h2 className="font-display text-2xl text-forest dark:text-sage-light mb-3">Want to see what we're growing?</h2>
        <button
          onClick={() => setView('catalog')}
          className="focus-ring px-6 py-3 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors"
        >
          Browse the catalog
        </button>
      </section>
    </div>
  )
}

function AboutCard({ icon, title, text }) {
  return (
    <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
      <div className="w-9 h-9 rounded-full bg-clay/10 text-clay flex items-center justify-center mb-3">
        {icon}
      </div>
      <p className="font-medium mb-1">{title}</p>
      <p className="text-sm text-[var(--text-muted)] leading-relaxed">{text}</p>
    </div>
  )
}
