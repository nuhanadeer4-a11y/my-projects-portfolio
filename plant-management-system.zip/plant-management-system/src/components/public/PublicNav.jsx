import React, { useState } from 'react'
import { LeafIcon, MoonIcon, SunFilledIcon } from '../icons.jsx'
import { useAppDispatch, useAppState } from '../../context/AppContext.jsx'

const LINKS = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'contact', label: 'Contact Us' },
]

export default function PublicNav({ view, setView }) {
  const { theme } = useAppState()
  const dispatch = useAppDispatch()
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 border-b border-[var(--border)] bg-[var(--surface)]/90 backdrop-blur">
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <button
          onClick={() => setView('home')}
          className="focus-ring flex items-center gap-2"
        >
          <LeafIcon className="w-6 h-6 text-forest dark:text-sage-light" />
          <span className="font-display text-xl italic text-forest dark:text-sage-light">Thottam</span>
        </button>

        <nav className="hidden sm:flex items-center gap-1">
          {LINKS.map((l) => (
            <button
              key={l.id}
              onClick={() => setView(l.id)}
              className={`focus-ring px-4 py-2 rounded-sm text-sm font-medium transition-colors ${
                view === l.id
                  ? 'text-clay'
                  : 'text-charcoal/70 dark:text-[var(--text-muted)] hover:text-clay'
              }`}
            >
              {l.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            aria-label="Toggle theme"
            onClick={() => dispatch({ type: 'TOGGLE_THEME' })}
            className="focus-ring w-9 h-9 rounded-full border border-[var(--border)] flex items-center justify-center hover:border-clay transition-colors"
          >
            {theme === 'light' ? <MoonIcon /> : <SunFilledIcon />}
          </button>
          <button
            onClick={() => setView('login')}
            className="focus-ring text-sm px-4 py-2 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors"
          >
            Login
          </button>
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="focus-ring sm:hidden w-9 h-9 rounded-full border border-[var(--border)] flex items-center justify-center"
            aria-label="Menu"
          >
            <span className="text-lg leading-none">☰</span>
          </button>
        </div>
      </div>

      {menuOpen && (
        <nav className="sm:hidden border-t border-[var(--border)] px-6 py-3 flex flex-col gap-1">
          {LINKS.map((l) => (
            <button
              key={l.id}
              onClick={() => { setView(l.id); setMenuOpen(false) }}
              className={`focus-ring text-left px-3 py-2 rounded-sm text-sm font-medium ${
                view === l.id ? 'text-clay' : 'text-[var(--text-muted)]'
              }`}
            >
              {l.label}
            </button>
          ))}
        </nav>
      )}
    </header>
  )
}
