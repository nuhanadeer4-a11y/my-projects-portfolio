import React, { useState } from 'react'
import { useAppState } from '../../context/AppContext.jsx'
import { formatLKR } from '../../utils/currency.js'
import { LeafIcon, SunIcon, DropIcon, ShieldIcon, BoxIcon } from '../icons.jsx'
import PlantArt from '../PlantArt.jsx'

function PlantThumb({ plant, className }) {
  const [failed, setFailed] = useState(false)
  if (plant.image && !failed) {
    return (
      <img
        src={plant.image}
        alt={plant.name}
        className={className}
        onError={() => setFailed(true)}
      />
    )
  }
  return <PlantArt name={plant.name} className={className} />
}

export default function Home({ setView }) {
  const { plants } = useAppState()
  const featured = plants.slice(0, 4)

  return (
    <div>
      <section className="max-w-6xl mx-auto px-6 pt-16 pb-20 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
        <div>
          <span className="text-xs uppercase tracking-wide text-clay font-medium">Sri Lanka's plant nursery</span>
          <h1 className="font-display text-4xl md:text-5xl leading-tight mt-3 mb-5 text-forest dark:text-sage-light">
            Bring your home to life, one plant at a time
          </h1>
          <p className="text-[var(--text-muted)] leading-relaxed mb-8 max-w-md">
            From low-maintenance succulents to fragrant jasmine, we grow and deliver
            healthy plants across the island — with care instructions for every pot.
          </p>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => setView('login')}
              className="focus-ring px-6 py-3 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors"
            >
              Shop plants
            </button>
            <button
              onClick={() => setView('about')}
              className="focus-ring px-6 py-3 rounded-sm border border-[var(--border)] hover:border-clay hover:text-clay font-medium transition-colors"
            >
              Learn more
            </button>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {featured.slice(0, 4).map((p) => (
            <div key={p.id} className="stamp-in border border-[var(--border)] rounded-sm bg-[var(--surface)] overflow-hidden">
              <div className="h-28">
                <PlantThumb plant={p} className="w-full h-full object-cover" />
              </div>
              <div className="p-2.5">
                <p className="text-sm font-medium leading-tight">{p.name}</p>
                <p className="text-xs text-clay">{formatLKR(p.price)}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="border-y border-[var(--border)] bg-forest/5 dark:bg-white/5">
        <div className="max-w-6xl mx-auto px-6 py-14 grid grid-cols-1 sm:grid-cols-3 gap-8">
          <Feature icon={<LeafIcon className="w-5 h-5" />} title="Healthy, ready-to-pot plants" text="Every plant is nursery-raised and inspected before it leaves us." />
          <Feature icon={<BoxIcon className="w-5 h-5" />} title="Island-wide delivery" text="Ordered today, carefully packed and on its way to your door." />
          <Feature icon={<ShieldIcon className="w-5 h-5" />} title="Care guidance included" text="Watering, sunlight and fertilizer notes with every plant you buy." />
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="flex items-end justify-between mb-6">
          <h2 className="font-display text-2xl text-forest dark:text-sage-light">Popular right now</h2>
          <button onClick={() => setView('login')} className="focus-ring text-sm text-clay hover:underline">
            View full catalog →
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {featured.map((p) => (
            <div key={p.id} className="border border-[var(--border)] rounded-sm bg-[var(--surface)] overflow-hidden">
              <div className="h-32">
                <PlantThumb plant={p} className="w-full h-full object-cover" />
              </div>
              <div className="p-3">
                <p className="text-sm font-medium leading-tight">{p.name}</p>
                <p className="text-xs text-[var(--text-muted)] mb-2">{p.category}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-display text-forest dark:text-sage-light">{formatLKR(p.price)}</span>
                  <span className="flex items-center gap-2 text-[var(--text-muted)]">
                    <SunIcon className="w-3.5 h-3.5" />
                    <DropIcon className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
        <p className="text-center text-sm text-[var(--text-muted)] mt-8">
          Log in to add plants to your cart and place an order.
        </p>
      </section>
    </div>
  )
}

function Feature({ icon, title, text }) {
  return (
    <div>
      <div className="w-10 h-10 rounded-full bg-forest text-linen dark:bg-sage-light dark:text-forest-dark flex items-center justify-center mb-3">
        {icon}
      </div>
      <h3 className="font-display text-lg mb-1">{title}</h3>
      <p className="text-sm text-[var(--text-muted)] leading-relaxed">{text}</p>
    </div>
  )
}
