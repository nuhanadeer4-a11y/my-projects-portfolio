import React from 'react'
import { LeafIcon, SunIcon, ShieldIcon } from '../icons.jsx'

export default function About() {
  return (
    <div className="max-w-4xl mx-auto px-6 py-16">
      <span className="text-xs uppercase tracking-wide text-clay font-medium">About us</span>
      <h1 className="font-display text-3xl md:text-4xl mt-2 mb-6 text-forest dark:text-sage-light">
        Grown with care, since day one
      </h1>
      <p className="text-[var(--text-muted)] leading-relaxed mb-4">
        Thottam started as a small family nursery, growing plants suited to Sri Lanka's
        climate — from sun-loving hibiscus to low-light indoor favourites. What began with
        a handful of pots on a home veranda has grown into a nursery trusted by hundreds
        of plant lovers across the island.
      </p>
      <p className="text-[var(--text-muted)] leading-relaxed mb-10">
        We believe a healthy plant starts long before it reaches your home — with the right
        soil, the right amount of sun, and someone who genuinely enjoys growing things. Every
        plant that leaves our nursery comes with clear care instructions, because we want it
        to thrive with you, not just survive the trip home.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
        <ValueCard icon={<LeafIcon className="w-5 h-5" />} title="Nursery-raised" text="Every plant is grown and hardened at our own nursery before sale." />
        <ValueCard icon={<SunIcon className="w-5 h-5" />} title="Climate-suited" text="We stock varieties that genuinely do well in Sri Lankan homes." />
        <ValueCard icon={<ShieldIcon className="w-5 h-5" />} title="Care support" text="Watering and light guidance included with every order." />
      </div>

      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-6">
        <h2 className="font-display text-xl mb-2">Our mission</h2>
        <p className="text-[var(--text-muted)] leading-relaxed">
          To make it easy for every home in Sri Lanka to keep something green and growing —
          with honest advice, fair prices in LKR, and plants that are ready for real homes,
          not just showrooms.
        </p>
      </div>
    </div>
  )
}

function ValueCard({ icon, title, text }) {
  return (
    <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
      <div className="w-9 h-9 rounded-full bg-forest text-linen dark:bg-sage-light dark:text-forest-dark flex items-center justify-center mb-3">
        {icon}
      </div>
      <h3 className="font-medium mb-1">{title}</h3>
      <p className="text-sm text-[var(--text-muted)] leading-relaxed">{text}</p>
    </div>
  )
}
