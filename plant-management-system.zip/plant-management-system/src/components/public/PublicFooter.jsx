import React from 'react'
import { LeafIcon } from '../icons.jsx'

export default function PublicFooter({ setView }) {
  return (
    <footer className="border-t border-[var(--border)] mt-16">
      <div className="max-w-6xl mx-auto px-6 py-10 grid grid-cols-1 sm:grid-cols-3 gap-8">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <LeafIcon className="w-5 h-5 text-forest dark:text-sage-light" />
            <span className="font-display text-lg italic text-forest dark:text-sage-light">Thottam</span>
          </div>
          <p className="text-sm text-[var(--text-muted)]">
            Healthy plants, delivered across Sri Lanka with care instructions included.
          </p>
        </div>
        <div>
          <p className="text-xs uppercase tracking-wide text-[var(--text-muted)] mb-2">Quick links</p>
          <div className="flex flex-col gap-1.5 text-sm">
            <button onClick={() => setView('home')} className="focus-ring text-left hover:text-clay">Home</button>
            <button onClick={() => setView('about')} className="focus-ring text-left hover:text-clay">About</button>
            <button onClick={() => setView('contact')} className="focus-ring text-left hover:text-clay">Contact Us</button>
            <button onClick={() => setView('login')} className="focus-ring text-left hover:text-clay">Login</button>
          </div>
        </div>
        <div>
          <p className="text-xs uppercase tracking-wide text-[var(--text-muted)] mb-2">Visit us</p>
          <p className="text-sm text-[var(--text-muted)] leading-relaxed">
            142 Galle Road, Colombo 03, Sri Lanka<br />
            Open daily · 8:00 AM – 6:00 PM<br />
            +94 77 123 4567
          </p>
        </div>
      </div>
      <p className="text-center text-xs text-[var(--text-muted)] pb-6">
        © {new Date().getFullYear()} Thottam Nursery. All rights reserved.
      </p>
    </footer>
  )
}
