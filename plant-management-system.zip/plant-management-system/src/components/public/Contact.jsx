import React, { useState } from 'react'
import { MailIcon, PhoneIcon, CheckIcon } from '../icons.jsx'

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [errors, setErrors] = useState({})
  const [sent, setSent] = useState(false)
  const [sending, setSending] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    const next = {}
    if (!form.name.trim()) next.name = 'Name is required'
    if (!/^\S+@\S+\.\S+$/.test(form.email)) next.email = 'Enter a valid email'
    if (!form.message.trim()) next.message = 'Message is required'
    setErrors(next)
    if (Object.keys(next).length) return

    setSending(true)
    // Simulated send — swap for a real EmailJS call or backend endpoint to
    // actually deliver this to the nursery's inbox.
    await new Promise((r) => setTimeout(r, 900))
    setSending(false)
    setSent(true)
    setForm({ name: '', email: '', message: '' })
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-16 grid grid-cols-1 md:grid-cols-2 gap-10">
      <div>
        <span className="text-xs uppercase tracking-wide text-clay font-medium">Contact us</span>
        <h1 className="font-display text-3xl mt-2 mb-4 text-forest dark:text-sage-light">
          We'd love to hear from you
        </h1>
        <p className="text-[var(--text-muted)] leading-relaxed mb-6">
          Questions about a plant, a bulk order, or delivery to your area — reach out and
          our team will get back to you.
        </p>

        <div className="space-y-3 text-sm">
          <p className="flex items-center gap-2"><MailIcon className="w-4 h-4 text-clay" /> hello@thottam.lk</p>
          <p className="flex items-center gap-2"><PhoneIcon className="w-4 h-4 text-clay" /> +94 77 123 4567</p>
        </div>
        <p className="text-sm text-[var(--text-muted)] mt-6 leading-relaxed">
          142 Galle Road, Colombo 03, Sri Lanka<br />
          Open daily · 8:00 AM – 6:00 PM
        </p>
      </div>

      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-6">
        {sent ? (
          <div className="stamp-in text-center py-8">
            <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-forest/10 dark:bg-sage-light/10 flex items-center justify-center">
              <CheckIcon className="w-6 h-6 text-forest dark:text-sage-light" />
            </div>
            <p className="font-display text-lg mb-1">Message sent</p>
            <p className="text-sm text-[var(--text-muted)]">We'll get back to you soon.</p>
            <button onClick={() => setSent(false)} className="focus-ring text-xs text-clay hover:underline mt-4">
              Send another message
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Your name"
                className="focus-ring w-full px-3 py-2.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
              />
              {errors.name && <p className="text-xs text-rose mt-1">{errors.name}</p>}
            </div>
            <div>
              <input
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="Your email"
                className="focus-ring w-full px-3 py-2.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
              />
              {errors.email && <p className="text-xs text-rose mt-1">{errors.email}</p>}
            </div>
            <div>
              <textarea
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                placeholder="How can we help?"
                rows={5}
                className="focus-ring w-full px-3 py-2.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
              />
              {errors.message && <p className="text-xs text-rose mt-1">{errors.message}</p>}
            </div>
            <button
              type="submit"
              disabled={sending}
              className="focus-ring w-full py-3 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors disabled:opacity-60"
            >
              {sending ? 'Sending…' : 'Send message'}
            </button>
          </form>
        )}
      </div>
    </div>
  )
}
