import React, { useState } from 'react'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'

export default function Categories() {
  const { categories, plants } = useAppState()
  const dispatch = useAppDispatch()
  const [name, setName] = useState('')
  const [editingId, setEditingId] = useState(null)
  const [editingName, setEditingName] = useState('')

  function handleAdd(e) {
    e.preventDefault()
    if (!name.trim()) return
    dispatch({
      type: 'ADD_CATEGORY',
      category: { id: 'CAT-' + Date.now().toString().slice(-6), name: name.trim() },
    })
    setName('')
  }

  function startEdit(cat) {
    setEditingId(cat.id)
    setEditingName(cat.name)
  }

  function saveEdit(cat) {
    if (!editingName.trim()) return
    dispatch({ type: 'UPDATE_CATEGORY', category: { ...cat, name: editingName.trim() } })
    setEditingId(null)
  }

  function handleDelete(cat) {
    const inUse = plants.some((p) => p.category === cat.name)
    if (inUse) {
      alert(`Can't delete "${cat.name}" — some plants still use this category. Reassign them first.`)
      return
    }
    dispatch({ type: 'DELETE_CATEGORY', id: cat.id })
  }

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12 max-w-xl">
      <form onSubmit={handleAdd} className="flex gap-2 mb-6">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="New category name, e.g. Bonsai"
          className="focus-ring flex-1 px-3 py-2.5 rounded-sm border border-[var(--border)] bg-[var(--surface)] text-sm"
        />
        <button
          type="submit"
          className="focus-ring px-4 py-2.5 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark text-sm font-medium"
        >
          Add category
        </button>
      </form>

      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] divide-y divide-[var(--border)]">
        {categories.map((cat) => {
          const count = plants.filter((p) => p.category === cat.name).length
          return (
            <div key={cat.id} className="flex items-center gap-3 p-4">
              {editingId === cat.id ? (
                <input
                  value={editingName}
                  onChange={(e) => setEditingName(e.target.value)}
                  autoFocus
                  className="focus-ring flex-1 px-2 py-1.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
                />
              ) : (
                <div className="flex-1">
                  <p className="font-medium text-sm">{cat.name}</p>
                  <p className="text-xs text-[var(--text-muted)]">{count} plant{count !== 1 ? 's' : ''}</p>
                </div>
              )}

              {editingId === cat.id ? (
                <>
                  <button onClick={() => saveEdit(cat)} className="focus-ring text-xs text-clay hover:underline">
                    Save
                  </button>
                  <button onClick={() => setEditingId(null)} className="focus-ring text-xs text-[var(--text-muted)] hover:underline">
                    Cancel
                  </button>
                </>
              ) : (
                <>
                  <button onClick={() => startEdit(cat)} className="focus-ring text-xs text-clay hover:underline">
                    Edit
                  </button>
                  <button onClick={() => handleDelete(cat)} className="focus-ring text-xs text-rose/70 hover:text-rose hover:underline">
                    Delete
                  </button>
                </>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
