import React from 'react'
import { useAppState } from '../context/AppContext.jsx'
import { formatLKR } from '../utils/currency.js'
import { LeafIcon, SunIcon, DropIcon, ShieldIcon, BoxIcon } from './icons.jsx'

export default function Home({ setView }) {
  const { plants, categories } = useAppState()
  const featured = plants.slice(0, 4)

  return (
    <div>
      {/* Hero */}
      <section className="border-b border-[var(--border)]">
        <div className="max-w-6xl mx-auto px-6 py-16 md:py-24 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
          <div>
            <span className="text-xs uppercase tracking-widest text-clay">Sri Lanka's plant nursery, online</span>
            <h1 className="font-display text-4xl md:text-5xl leading-tight text-forest dark:text-sage-light mt-3 mb-4">
              Bring a little green into every room
            </h1>
            <p className="text-[var(--text-muted)] leading-relaxed mb-6">
              From money plants to bonsai — hand-picked, healthy plants delivered
              to your door, with care instructions for every leaf. Browse the
              catalog, order in minutes, and we'll confirm by email or SMS.
            </p>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => setView('catalog')}
                className="focus-ring px-6 py-3 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors"
              >
                Shop the catalog
              </button>
              <button
                onClick={() => setView('about')}
                className="focus-ring px-6 py-3 rounded-sm border border-[var(--border)] hover:border-clay hover:text-clay font-medium transition-colors"
              >
                Our story
              </button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {featured.slice(0, 4).map((p) => (
              <div key={p.id} className="stamp-in border border-[var(--border)] rounded-sm bg-[var(--surface)] overflow-hidden">
                <div className="h-28 bg-forest/5 dark:bg-white/5">
                  {p.image && <img src={p.image} alt={p.name} className="w-full h-full object-cover" />}
                </div>
                <div className="p-2.5">
                  <p className="text-xs font-medium">{p.name}</p>
                  <p className="text-xs text-clay">{formatLKR(p.price)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Value props */}
      <section className="max-w-6xl mx-auto px-6 py-14 grid grid-cols-1 sm:grid-cols-3 gap-6">
        <ValueCard icon={<LeafIcon className="w-5 h-5" />} title="Healthy, hand-picked plants" text="Every plant is inspected before it leaves the nursery." />
        <ValueCard icon={<BoxIcon className="w-5 h-5" />} title="Order confirmation, always" text="Email if you give one, SMS if you don't — you'll always know your order went through." />
        <ValueCard icon={<ShieldIcon className="w-5 h-5" />} title="Care that doesn't stop at delivery" text="Watering, sunlight and fertilizer notes come with every plant." />
      </section>

      {/* Categories */}
      <section className="border-t border-[var(--border)] bg-forest/5 dark:bg-white/5">
        <div className="max-w-6xl mx-auto px-6 py-14">
          <h2 className="font-display text-2xl text-forest dark:text-sage-light mb-6">Shop by category</h2>
          <div className="flex flex-wrap gap-3">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setView('catalog')}
                className="focus-ring px-4 py-2.5 rounded-full border border-[var(--border)] bg-[var(--surface)] text-sm hover:border-clay hover:text-clay transition-colors"
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured plants */}
      <section className="max-w-6xl mx-auto px-6 py-14">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-2xl text-forest dark:text-sage-light">Featured plants</h2>
          <button onClick={() => setView('catalog')} className="focus-ring text-sm text-clay hover:underline">
            View all →
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {featured.map((p) => (
            <div key={p.id} className="border border-[var(--border)] rounded-sm bg-[var(--surface)] overflow-hidden">
              <div className="h-36 bg-forest/5 dark:bg-white/5">
                {p.image && <img src={p.image} alt={p.name} className="w-full h-full object-cover" />}
              </div>
              <div className="p-4">
                <p className="font-display text-lg">{p.name}</p>
                <p className="text-xs text-[var(--text-muted)] mb-2">{p.category}</p>
                <div className="flex items-center justify-between">
                  <span className="font-display text-forest dark:text-sage-light">{formatLKR(p.price)}</span>
                  <span className="flex items-center gap-2 text-[var(--text-muted)]">
                    <SunIcon className="w-3.5 h-3.5" />
                    <DropIcon className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-[var(--border)]">
        <div className="max-w-6xl mx-auto px-6 py-14 text-center">
          <h2 className="font-display text-2xl md:text-3xl text-forest dark:text-sage-light mb-3">
            Ready to green up your space?
          </h2>
          <p className="text-[var(--text-muted)] mb-6">Browse the full catalog and get plants delivered this week.</p>
          <button
            onClick={() => setView('catalog')}
            className="focus-ring px-6 py-3 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors"
          >
            Start shopping
          </button>
        </div>
      </section>
    </div>
  )
}

function ValueCard({ icon, title, text }) {
  return (
    <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
      <div className="w-9 h-9 rounded-full bg-clay/10 text-clay flex items-center justify-center mb-3">
        {icon}
      </div>
      <p className="font-medium mb-1">{title}</p>
      <p className="text-sm text-[var(--text-muted)] leading-relaxed">{text}</p>
    </div>
  )
}
