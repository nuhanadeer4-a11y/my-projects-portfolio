import React, { useState } from 'react'
import { SunIcon, DropIcon } from './icons.jsx'
import { useAppDispatch } from '../context/AppContext.jsx'
import { formatLKR } from '../utils/currency.js'
import PlantArt from './PlantArt.jsx'

export default function PlantCard({ plant }) {
  const dispatch = useAppDispatch()
  const [imgFailed, setImgFailed] = useState(false)
  const isLow = plant.stock <= plant.lowStockAt && plant.stock > 0
  const isOut = plant.stock === 0
  const showPhoto = plant.image && !imgFailed

  return (
    <div className="stamp-in group relative border border-[var(--border)] rounded-sm bg-[var(--surface)] overflow-hidden flex flex-col hover:border-clay/60 transition-colors">
      <div className="relative h-40 overflow-hidden">
        {showPhoto ? (
          <img
            src={plant.image}
            alt={plant.name}
            loading="lazy"
            className="w-full h-full object-cover"
            onError={() => setImgFailed(true)}
          />
        ) : (
          <PlantArt name={plant.name} />
        )}
        <span className="absolute top-2 right-2 text-[10px] uppercase tracking-wide text-clay bg-[var(--surface)]/90 border border-clay/40 rounded-full px-2 py-0.5">
          {plant.category}
        </span>
      </div>

      <div className="p-5 flex flex-col gap-3 flex-1">
        <div>
          <h3 className="font-display text-lg leading-tight">{plant.name}</h3>
          <p className="text-xs text-[var(--text-muted)]">{plant.tamilName}</p>
        </div>

        <p className="text-sm text-[var(--text-muted)] leading-relaxed flex-1">
          {plant.description}
        </p>

        <div className="flex items-center gap-4 text-xs text-[var(--text-muted)]">
          <span className="flex items-center gap-1">
            <SunIcon className="w-3.5 h-3.5" /> {plant.light}
          </span>
          <span className="flex items-center gap-1">
            <DropIcon className="w-3.5 h-3.5" /> {plant.water}
          </span>
        </div>

        <div className="leaf-divider" />

        <div className="flex items-center justify-between">
          <div>
            <span className="font-display text-xl text-forest dark:text-sage-light">
              {formatLKR(plant.price)}
            </span>
            {isOut ? (
              <p className="text-xs text-rose mt-0.5">Out of stock</p>
            ) : isLow ? (
              <p className="text-xs text-amber mt-0.5">Only {plant.stock} left</p>
            ) : (
              <p className="text-xs text-[var(--text-muted)] mt-0.5">{plant.stock} in stock</p>
            )}
          </div>
          <button
            disabled={isOut}
            onClick={() => dispatch({ type: 'ADD_TO_CART', plant })}
            className="focus-ring text-sm font-medium px-4 py-2 rounded-sm bg-forest text-linen hover:bg-forest-light disabled:opacity-30 disabled:cursor-not-allowed dark:bg-sage-light dark:text-forest-dark transition-colors"
          >
            Add to cart
          </button>
        </div>
      </div>
    </div>
  )
}
