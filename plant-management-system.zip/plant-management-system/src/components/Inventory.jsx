import React, { useState } from 'react'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'
import { AlertIcon } from './icons.jsx'

export default function Inventory() {
  const { plants, stockHistory } = useAppState()
  const dispatch = useAppDispatch()
  const [adjust, setAdjust] = useState({}) // plantId -> pending qty string
  const [reason, setReason] = useState({}) // plantId -> reason text

  const lowStockPlants = plants.filter((p) => p.stock <= p.lowStockAt)

  function applyAdjustment(plantId, sign) {
    const qty = Number(adjust[plantId])
    if (!qty || qty <= 0) return
    dispatch({
      type: 'ADJUST_STOCK',
      plantId,
      delta: sign * qty,
      reason: reason[plantId]?.trim() || (sign > 0 ? 'Stock received' : 'Stock removed'),
    })
    setAdjust((a) => ({ ...a, [plantId]: '' }))
    setReason((r) => ({ ...r, [plantId]: '' }))
  }

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12 grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-6">
      <div>
        {lowStockPlants.length > 0 && (
          <div className="mb-5 flex items-start gap-2 border border-amber/40 bg-amber/10 text-amber-900 dark:text-amber rounded-sm p-3 text-sm">
            <AlertIcon className="w-4 h-4 mt-0.5 shrink-0" />
            <p>
              <strong>{lowStockPlants.length} plant{lowStockPlants.length > 1 ? 's' : ''}</strong> running low:{' '}
              {lowStockPlants.map((p) => p.name).join(', ')}
            </p>
          </div>
        )}

        <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] divide-y divide-[var(--border)]">
          {plants.map((p) => (
            <div key={p.id} className="p-4 flex flex-wrap items-center gap-3">
              <div className="flex-1 min-w-[140px]">
                <p className="font-medium text-sm">{p.name}</p>
                <p className={`text-xs ${p.stock <= p.lowStockAt ? 'text-amber' : 'text-[var(--text-muted)]'}`}>
                  {p.stock} in stock {p.stock <= p.lowStockAt && '· low'}
                </p>
              </div>
              <input
                type="number"
                min="1"
                value={adjust[p.id] || ''}
                onChange={(e) => setAdjust((a) => ({ ...a, [p.id]: e.target.value }))}
                placeholder="Qty"
                className="focus-ring w-20 px-2 py-1.5 rounded-sm border border-[var(--border)] bg-transparent text-sm"
              />
              <input
                value={reason[p.id] || ''}
                onChange={(e) => setReason((r) => ({ ...r, [p.id]: e.target.value }))}
                placeholder="Reason (optional)"
                className="focus-ring w-40 px-2 py-1.5 rounded-sm border border-[var(--border)] bg-transparent text-sm hidden sm:block"
              />
              <button
                onClick={() => applyAdjustment(p.id, 1)}
                className="focus-ring text-xs px-3 py-1.5 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark"
              >
                + Add stock
              </button>
              <button
                onClick={() => applyAdjustment(p.id, -1)}
                className="focus-ring text-xs px-3 py-1.5 rounded-sm border border-rose/40 text-rose hover:bg-rose/10"
              >
                − Reduce
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5 h-fit">
        <h3 className="font-display text-lg mb-3">Stock history</h3>
        {stockHistory.length === 0 ? (
          <p className="text-sm text-[var(--text-muted)]">Adjustments will be logged here.</p>
        ) : (
          <ul className="space-y-3 max-h-[60vh] overflow-y-auto">
            {stockHistory.map((h) => (
              <li key={h.id} className="text-sm border-b border-[var(--border)] pb-2 last:border-0">
                <p>
                  <span className={h.delta > 0 ? 'text-forest dark:text-sage-light' : 'text-rose'}>
                    {h.delta > 0 ? '+' : ''}{h.delta}
                  </span>{' '}
                  {h.plantName}
                </p>
                <p className="text-xs text-[var(--text-muted)]">
                  {h.reason} · {new Date(h.at).toLocaleString('en-LK')}
                </p>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
