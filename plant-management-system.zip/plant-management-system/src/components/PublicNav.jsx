import React, { useState } from 'react'
import { LeafIcon, MoonIcon, SunFilledIcon, UserIcon, CartIcon } from './icons.jsx'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'

const LINKS = [
  { id: 'home', label: 'Home' },
  { id: 'catalog', label: 'Shop' },
  { id: 'about', label: 'About' },
  { id: 'contact', label: 'Contact Us' },
]

export default function PublicNav({ view, setView }) {
  const { theme, cart } = useAppState()
  const dispatch = useAppDispatch()
  const [menuOpen, setMenuOpen] = useState(false)
  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0)

  function go(id) {
    setView(id)
    setMenuOpen(false)
  }

  return (
    <header className="border-b border-[var(--border)] bg-[var(--surface)] sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <button onClick={() => go('home')} className="focus-ring flex items-center gap-2">
          <LeafIcon className="w-6 h-6 text-forest dark:text-sage-light" />
          <span className="font-display text-xl italic text-forest dark:text-sage-light">Thottam</span>
        </button>

        <nav className="hidden md:flex items-center gap-1">
          {LINKS.map((l) => (
            <button
              key={l.id}
              onClick={() => go(l.id)}
              className={`focus-ring px-3 py-2 text-sm font-medium rounded-sm transition-colors ${
                view === l.id
                  ? 'text-clay'
                  : 'text-[var(--text-muted)] hover:text-clay'
              }`}
            >
              {l.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            aria-label="Toggle theme"
            onClick={() => dispatch({ type: 'TOGGLE_THEME' })}
            className="focus-ring w-9 h-9 rounded-full border border-[var(--border)] flex items-center justify-center hover:border-clay transition-colors"
          >
            {theme === 'light' ? <MoonIcon /> : <SunFilledIcon />}
          </button>
          <button
            onClick={() => go('cart')}
            aria-label="Cart"
            className="focus-ring relative w-9 h-9 rounded-full border border-[var(--border)] flex items-center justify-center hover:border-clay transition-colors"
          >
            <CartIcon className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 text-[9px] bg-clay text-linen rounded-full w-4 h-4 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
          <button
            onClick={() => go('login')}
            className="focus-ring hidden sm:flex items-center gap-1.5 text-sm px-3 py-2 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors"
          >
            <UserIcon className="w-4 h-4" /> Log in
          </button>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="focus-ring md:hidden w-9 h-9 rounded-full border border-[var(--border)] flex items-center justify-center"
            aria-label="Menu"
          >
            <span className="text-lg leading-none">☰</span>
          </button>
        </div>
      </div>

      {menuOpen && (
        <nav className="md:hidden border-t border-[var(--border)] px-6 py-3 flex flex-col gap-1">
          {LINKS.map((l) => (
            <button
              key={l.id}
              onClick={() => go(l.id)}
              className={`focus-ring text-left px-2 py-2 text-sm font-medium rounded-sm ${
                view === l.id ? 'text-clay' : 'text-[var(--text-muted)]'
              }`}
            >
              {l.label}
            </button>
          ))}
          <button
            onClick={() => go('login')}
            className="focus-ring text-left px-2 py-2 text-sm font-medium text-clay"
          >
            Log in
          </button>
        </nav>
      )}
    </header>
  )
}
