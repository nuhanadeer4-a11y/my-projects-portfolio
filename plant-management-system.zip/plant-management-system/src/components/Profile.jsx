import React, { useState } from 'react'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'
import { hashPassword } from '../utils/auth.js'
import { UserIcon, LogoutIcon, LockIcon } from './icons.jsx'

export default function Profile({ setView }) {
  const { currentUser, users } = useAppState()
  const dispatch = useAppDispatch()
  const [name, setName] = useState(currentUser?.name || '')
  const [phone, setPhone] = useState(currentUser?.phone || '')
  const [savedMsg, setSavedMsg] = useState('')

  const [passwords, setPasswords] = useState({ current: '', next: '', confirm: '' })
  const [pwError, setPwError] = useState('')
  const [pwSaved, setPwSaved] = useState(false)

  function saveProfile(e) {
    e.preventDefault()
    dispatch({ type: 'UPDATE_PROFILE', userId: currentUser.id, changes: { name: name.trim(), phone: phone.trim() } })
    setSavedMsg('Profile updated')
    setTimeout(() => setSavedMsg(''), 2000)
  }

  function changePassword(e) {
    e.preventDefault()
    setPwError('')
    setPwSaved(false)
    const user = users.find((u) => u.id === currentUser.id)
    if (!user || user.passwordHash !== hashPassword(passwords.current)) {
      setPwError('Current password is incorrect')
      return
    }
    if (passwords.next.length < 6) {
      setPwError('New password must be at least 6 characters')
      return
    }
    if (passwords.next !== passwords.confirm) {
      setPwError('New passwords do not match')
      return
    }
    dispatch({ type: 'CHANGE_PASSWORD', userId: currentUser.id, passwordHash: hashPassword(passwords.next) })
    setPasswords({ current: '', next: '', confirm: '' })
    setPwSaved(true)
    setTimeout(() => setPwSaved(false), 2000)
  }

  function handleLogout() {
    dispatch({ type: 'LOGOUT' })
    setView('catalog')
  }

  if (!currentUser) return null

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12 max-w-lg space-y-6">
      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 rounded-full bg-forest text-linen dark:bg-sage-light dark:text-forest-dark flex items-center justify-center text-lg font-medium">
            {currentUser.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <p className="font-display text-lg">{currentUser.name}</p>
            <p className="text-xs text-[var(--text-muted)] uppercase tracking-wide">
              {currentUser.role === 'admin' ? 'Nursery staff' : 'Customer'}
            </p>
          </div>
        </div>

        <form onSubmit={saveProfile} className="space-y-3">
          <div>
            <label className="text-sm font-medium block mb-1">Name</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
            />
          </div>
          <div>
            <label className="text-sm font-medium block mb-1">Email</label>
            <input
              value={currentUser.email}
              disabled
              className="w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-black/5 dark:bg-white/5 text-sm text-[var(--text-muted)]"
            />
          </div>
          <div>
            <label className="text-sm font-medium block mb-1">Phone</label>
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
            />
          </div>
          <div className="flex items-center gap-3 pt-1">
            <button
              type="submit"
              className="focus-ring px-4 py-2 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark text-sm font-medium"
            >
              Save profile
            </button>
            {savedMsg && <span className="text-xs text-forest dark:text-sage-light">{savedMsg}</span>}
          </div>
        </form>
      </div>

      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-6">
        <h3 className="font-display text-lg mb-3 flex items-center gap-2">
          <LockIcon className="w-4 h-4" /> Change password
        </h3>
        <form onSubmit={changePassword} className="space-y-3">
          <input
            type="password"
            value={passwords.current}
            onChange={(e) => setPasswords({ ...passwords, current: e.target.value })}
            placeholder="Current password"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
          <input
            type="password"
            value={passwords.next}
            onChange={(e) => setPasswords({ ...passwords, next: e.target.value })}
            placeholder="New password"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
          <input
            type="password"
            value={passwords.confirm}
            onChange={(e) => setPasswords({ ...passwords, confirm: e.target.value })}
            placeholder="Confirm new password"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
          {pwError && <p className="text-xs text-rose">{pwError}</p>}
          {pwSaved && <p className="text-xs text-forest dark:text-sage-light">Password changed successfully</p>}
          <button
            type="submit"
            className="focus-ring px-4 py-2 rounded-sm border border-[var(--border)] hover:border-clay hover:text-clay text-sm font-medium transition-colors"
          >
            Update password
          </button>
        </form>
      </div>

      <button
        onClick={handleLogout}
        className="focus-ring w-full flex items-center justify-center gap-2 py-3 rounded-sm border border-rose/40 text-rose hover:bg-rose/10 text-sm font-medium transition-colors"
      >
        <LogoutIcon className="w-4 h-4" /> Log out
      </button>
    </div>
  )
}
