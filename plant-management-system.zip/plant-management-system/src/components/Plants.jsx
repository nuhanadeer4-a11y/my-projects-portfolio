import React, { useState } from 'react'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'
import { AlertIcon, LeafIcon } from './icons.jsx'
import { formatLKR } from '../utils/currency.js'

const emptyForm = {
  name: '',
  tamilName: '',
  category: '',
  price: '',
  stock: '',
  lowStockAt: '10',
  light: '',
  water: '',
  fertilizer: '',
  temperature: '',
  careInstructions: '',
  description: '',
  image: '',
}

// Converts an uploaded image file to a base64 data URL so it can be stored
// entirely client-side (no backend/storage bucket needed for this demo).
function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

export default function Plants() {
  const { plants, categories } = useAppState()
  const dispatch = useAppDispatch()
  const [form, setForm] = useState(emptyForm)
  const [editingId, setEditingId] = useState(null)
  const [imageError, setImageError] = useState('')

  function resetForm() {
    setForm(emptyForm)
    setEditingId(null)
    setImageError('')
  }

  async function handleImageChange(e) {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 1.5 * 1024 * 1024) {
      setImageError('Please choose an image under 1.5MB')
      return
    }
    setImageError('')
    const dataUrl = await fileToDataUrl(file)
    setForm((f) => ({ ...f, image: dataUrl }))
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (!form.name.trim() || !form.price) return

    const plant = {
      id: editingId || 'PLT-' + Date.now().toString().slice(-6),
      name: form.name.trim(),
      tamilName: form.tamilName.trim(),
      category: form.category || categories[0]?.name || 'Uncategorised',
      price: Number(form.price),
      stock: Number(form.stock) || 0,
      lowStockAt: Number(form.lowStockAt) || 10,
      light: form.light.trim() || '—',
      water: form.water.trim() || '—',
      fertilizer: form.fertilizer.trim() || '—',
      temperature: form.temperature.trim() || '—',
      careInstructions: form.careInstructions.trim(),
      description: form.description.trim(),
      image: form.image,
    }

    dispatch({ type: editingId ? 'UPDATE_PLANT' : 'ADD_PLANT', plant })
    resetForm()
  }

  function handleEdit(plant) {
    setForm({
      name: plant.name,
      tamilName: plant.tamilName,
      category: plant.category,
      price: String(plant.price),
      stock: String(plant.stock),
      lowStockAt: String(plant.lowStockAt),
      light: plant.light,
      water: plant.water,
      fertilizer: plant.fertilizer || '',
      temperature: plant.temperature || '',
      careInstructions: plant.careInstructions || '',
      description: plant.description,
      image: plant.image || '',
    })
    setEditingId(plant.id)
    setImageError('')
  }

  const lowStockPlants = plants.filter((p) => p.stock <= p.lowStockAt)

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12 grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-6">
      <div>
        {lowStockPlants.length > 0 && (
          <div className="mb-5 flex items-start gap-2 border border-amber/40 bg-amber/10 text-amber-900 dark:text-amber rounded-sm p-3 text-sm">
            <AlertIcon className="w-4 h-4 mt-0.5 shrink-0" />
            <p>
              <strong>{lowStockPlants.length} plant{lowStockPlants.length > 1 ? 's' : ''}</strong> running low:{' '}
              {lowStockPlants.map((p) => p.name).join(', ')}
            </p>
          </div>
        )}

        <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs uppercase tracking-wide text-[var(--text-muted)] border-b border-[var(--border)]">
                <th className="p-3">Plant</th>
                <th className="p-3">Category</th>
                <th className="p-3">Price</th>
                <th className="p-3">Stock</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {plants.map((p) => (
                <tr key={p.id} className="border-b border-[var(--border)] last:border-0">
                  <td className="p-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-sm bg-forest/10 dark:bg-white/5 overflow-hidden shrink-0 flex items-center justify-center">
                        {p.image ? (
                          <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                        ) : (
                          <LeafIcon className="w-4 h-4 text-[var(--text-muted)]" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{p.name}</p>
                        <p className="text-xs text-[var(--text-muted)]">{p.tamilName}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-3 text-[var(--text-muted)]">{p.category}</td>
                  <td className="p-3">{formatLKR(p.price)}</td>
                  <td className="p-3">
                    <span className={p.stock <= p.lowStockAt ? 'text-amber font-medium' : ''}>
                      {p.stock}
                    </span>
                  </td>
                  <td className="p-3 text-right whitespace-nowrap">
                    <button
                      onClick={() => handleEdit(p)}
                      className="focus-ring text-xs text-clay hover:underline mr-3"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => dispatch({ type: 'DELETE_PLANT', id: p.id })}
                      className="focus-ring text-xs text-rose/70 hover:text-rose hover:underline"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5 h-fit space-y-3 sticky top-6 max-h-[85vh] overflow-y-auto">
        <h3 className="font-display text-lg mb-1">{editingId ? 'Edit plant' : 'Add a new plant'}</h3>

        <div className="flex items-center gap-3">
          <div className="w-16 h-16 rounded-sm bg-forest/5 dark:bg-white/5 overflow-hidden shrink-0 flex items-center justify-center border border-[var(--border)]">
            {form.image ? (
              <img src={form.image} alt="Preview" className="w-full h-full object-cover" />
            ) : (
              <LeafIcon className="w-5 h-5 text-[var(--text-muted)]" />
            )}
          </div>
          <div className="flex-1">
            <label className="focus-ring inline-block text-xs px-3 py-2 rounded-sm border border-[var(--border)] cursor-pointer hover:border-clay">
              Upload photo
              <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
            </label>
            {imageError && <p className="text-xs text-rose mt-1">{imageError}</p>}
          </div>
        </div>

        <input
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          placeholder="Name (English)"
          className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
        />
        <input
          value={form.tamilName}
          onChange={(e) => setForm({ ...form, tamilName: e.target.value })}
          placeholder="Name (தமிழ் / optional)"
          className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
        />
        <select
          value={form.category}
          onChange={(e) => setForm({ ...form, category: e.target.value })}
          className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
        >
          <option value="">Select category</option>
          {categories.map((c) => (
            <option key={c.id} value={c.name}>{c.name}</option>
          ))}
        </select>
        <div className="grid grid-cols-2 gap-2">
          <input
            type="number"
            value={form.price}
            onChange={(e) => setForm({ ...form, price: e.target.value })}
            placeholder="Price (LKR)"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
          <input
            type="number"
            value={form.stock}
            onChange={(e) => setForm({ ...form, stock: e.target.value })}
            placeholder="Stock qty"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
        </div>
        <input
          type="number"
          value={form.lowStockAt}
          onChange={(e) => setForm({ ...form, lowStockAt: e.target.value })}
          placeholder="Low stock alert threshold"
          className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
        />
        <div className="grid grid-cols-2 gap-2">
          <input
            value={form.light}
            onChange={(e) => setForm({ ...form, light: e.target.value })}
            placeholder="Light needs"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
          <input
            value={form.water}
            onChange={(e) => setForm({ ...form, water: e.target.value })}
            placeholder="Watering"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <input
            value={form.fertilizer}
            onChange={(e) => setForm({ ...form, fertilizer: e.target.value })}
            placeholder="Fertilizer schedule"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
          <input
            value={form.temperature}
            onChange={(e) => setForm({ ...form, temperature: e.target.value })}
            placeholder="Temperature range"
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
          />
        </div>
        <textarea
          value={form.careInstructions}
          onChange={(e) => setForm({ ...form, careInstructions: e.target.value })}
          placeholder="Care instructions"
          rows={2}
          className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
        />
        <textarea
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="Short description (shown to customers)"
          rows={2}
          className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
        />

        <div className="flex gap-2 pt-1">
          <button
            type="submit"
            className="focus-ring flex-1 py-2.5 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark text-sm font-medium transition-colors"
          >
            {editingId ? 'Save changes' : 'Add plant'}
          </button>
          {editingId && (
            <button
              type="button"
              onClick={resetForm}
              className="focus-ring px-4 py-2.5 rounded-sm border border-[var(--border)] text-sm"
            >
              Cancel
            </button>
          )}
        </div>
      </form>
    </div>
  )
}
