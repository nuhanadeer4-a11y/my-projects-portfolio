import React, { useState } from 'react'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'
import { notifyCustomerOfOrder } from '../utils/notifications.js'
import { MailIcon, PhoneIcon, CheckIcon } from './icons.jsx'
import { formatLKR } from '../utils/currency.js'
import PaymentForm from './PaymentForm.jsx'

function generateOrderId() {
  return 'ORD-' + Math.random().toString(36).slice(2, 8).toUpperCase()
}

export default function Checkout({ onBack }) {
  const { cart, currentUser } = useAppState()
  const dispatch = useAppDispatch()

  const [form, setForm] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: currentUser?.phone || '',
    address: '',
  })
  const [errors, setErrors] = useState({})
  const [stage, setStage] = useState('form') // form | payment | sending | done
  const [notificationResult, setNotificationResult] = useState(null)
  const [paymentResult, setPaymentResult] = useState(null)
  const [placedOrder, setPlacedOrder] = useState(null)

  const total = cart.reduce((sum, i) => sum + i.qty * i.price, 0)

  function validate() {
    const next = {}
    if (!form.name.trim()) next.name = 'Name is required'
    if (!form.address.trim()) next.address = 'Delivery address is required'
    const hasEmail = form.email.trim().length > 0
    const hasPhone = form.phone.trim().length > 0
    if (!hasEmail && !hasPhone) {
      next.contact = 'Give an email OR a phone number so we can confirm your order'
    }
    if (hasEmail && !/^\S+@\S+\.\S+$/.test(form.email)) {
      next.email = 'That email looks incomplete'
    }
    if (hasPhone && !/^\d{10}$/.test(form.phone.replace(/\D/g, ''))) {
      next.phone = 'Enter a 10-digit phone number'
    }
    setErrors(next)
    return Object.keys(next).length === 0
  }

  function handleContinueToPayment(e) {
    e.preventDefault()
    if (!validate()) return
    setStage('payment')
  }

  async function handlePaid(payment) {
    setPaymentResult(payment)

    const order = {
      id: generateOrderId(),
      userId: currentUser?.id || null,
      customer: {
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        address: form.address.trim(),
      },
      items: cart.map((c) => ({ id: c.id, name: c.name, qty: c.qty, price: c.price })),
      total,
      status: 'Confirmed',
      payment,
      placedAt: new Date().toISOString(),
    }

    setStage('sending')
    setPlacedOrder(order)

    const result = await notifyCustomerOfOrder(order)

    dispatch({ type: 'PLACE_ORDER', order })
    dispatch({
      type: 'LOG_NOTIFICATION',
      entry: { orderId: order.id, ...result },
    })

    setNotificationResult(result)
    setStage('done')
  }

  if (stage === 'payment') {
    return (
      <div className="px-6 md:px-10 pb-24 md:pb-12 max-w-lg">
        <PaymentForm amount={total} onPaid={handlePaid} onBack={() => setStage('form')} />
      </div>
    )
  }

  if (stage === 'sending') {
    return (
      <div className="px-6 md:px-10 pb-24 md:pb-12 max-w-lg">
        <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-10 text-center">
          <div className="w-10 h-10 mx-auto mb-4 rounded-full border-2 border-clay border-t-transparent animate-spin" />
          <p className="font-display text-lg">Confirming your order…</p>
          <p className="text-sm text-[var(--text-muted)] mt-1">
            Routing a confirmation to {form.email ? 'your email' : 'your phone'}
          </p>
        </div>
      </div>
    )
  }

  if (stage === 'done') {
    const viaEmail = notificationResult.channel === 'email'
    return (
      <div className="px-6 md:px-10 pb-24 md:pb-12 max-w-lg">
        <div className="stamp-in border border-[var(--border)] rounded-sm bg-[var(--surface)] p-8">
          <div className="w-12 h-12 rounded-full bg-forest/10 dark:bg-sage-light/10 flex items-center justify-center mb-4">
            <CheckIcon className="w-6 h-6 text-forest dark:text-sage-light" />
          </div>
          <h2 className="font-display text-2xl mb-1">Order {placedOrder.id} confirmed</h2>
          <p className="text-sm text-[var(--text-muted)] mb-6">
            Thank you, {placedOrder.customer.name}. Your plants are being prepared.
          </p>

          <div className="border border-[var(--border)] rounded-sm p-4 bg-forest/5 dark:bg-white/5 mb-3">
            <div className="flex items-center gap-2 text-sm font-medium">
              {viaEmail ? <MailIcon className="w-4 h-4 text-clay" /> : <PhoneIcon className="w-4 h-4 text-clay" />}
              Confirmation sent via {viaEmail ? 'Email' : 'SMS'}
            </div>
            <p className="text-xs text-[var(--text-muted)] mt-1">
              {viaEmail
                ? `We emailed the details to ${notificationResult.to}.`
                : `No email was given, so we texted the details to ${notificationResult.to}.`}
            </p>
          </div>

          <div className="border border-[var(--border)] rounded-sm p-4">
            <p className="text-sm font-medium">
              {paymentResult.method === 'cod'
                ? 'Cash on delivery'
                : paymentResult.method === 'upi'
                ? `Paid via UPI (${paymentResult.upiId})`
                : `Paid via ${paymentResult.brand} card ending ${paymentResult.last4}`}
            </p>
            <p className="text-xs text-[var(--text-muted)] mt-1">
              Transaction ID: {paymentResult.transactionId}
            </p>
          </div>

          <button
            onClick={onBack}
            className="focus-ring w-full mt-6 py-3 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors"
          >
            Back to catalog
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12 max-w-lg">
      <button onClick={onBack} className="focus-ring text-sm text-[var(--text-muted)] hover:text-clay mb-4">
        ← Back to cart
      </button>

      <form onSubmit={handleContinueToPayment} className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-6 space-y-4">
        <div>
          <label className="text-sm font-medium block mb-1">Full name</label>
          <input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
            placeholder="Kavitha Rajan"
          />
          {errors.name && <p className="text-xs text-rose mt-1">{errors.name}</p>}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium block mb-1">Email (optional)</label>
            <input
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
              placeholder="you@example.com"
            />
            {errors.email && <p className="text-xs text-rose mt-1">{errors.email}</p>}
          </div>
          <div>
            <label className="text-sm font-medium block mb-1">Phone (optional)</label>
            <input
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
              placeholder="98765 43210"
            />
            {errors.phone && <p className="text-xs text-rose mt-1">{errors.phone}</p>}
          </div>
        </div>
        {errors.contact && <p className="text-xs text-rose -mt-2">{errors.contact}</p>}
        <p className="text-xs text-[var(--text-muted)] -mt-2">
          We'll email your confirmation if you give an email. Otherwise we'll send it by SMS.
        </p>

        <div>
          <label className="text-sm font-medium block mb-1">Delivery address</label>
          <textarea
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
            rows={3}
            className="focus-ring w-full px-3 py-2 rounded-sm border border-[var(--border)] bg-transparent text-sm"
            placeholder="Door No, Street, Area, City, PIN"
          />
          {errors.address && <p className="text-xs text-rose mt-1">{errors.address}</p>}
        </div>

        <div className="leaf-divider" />

        <div className="flex items-center justify-between text-sm">
          <span className="text-[var(--text-muted)]">Order total</span>
          <span className="font-display text-xl text-forest dark:text-sage-light">{formatLKR(total)}</span>
        </div>

        <button
          type="submit"
          className="focus-ring w-full py-3 rounded-sm bg-forest text-linen hover:bg-forest-light dark:bg-sage-light dark:text-forest-dark font-medium transition-colors"
        >
          Continue to payment
        </button>
      </form>
    </div>
  )
}
