import React, { useEffect, useState } from 'react'
import { MoonIcon, SunFilledIcon, UserIcon, LogoutIcon } from './icons.jsx'
import { useAppDispatch, useAppState } from '../context/AppContext.jsx'
import { requestNotificationPermission } from '../utils/notifications.js'

const TITLES = {
  dashboard: ['Dashboard', 'Sales and stock at a glance'],
  plants: ['Plant Management', 'Add, edit, or remove plants from the catalog'],
  categories: ['Plant Categories', 'Organise plants into categories'],
  inventory: ['Inventory', 'Add or reduce stock, and review stock history'],
  customers: ['Customer Management', 'Your nursery\u2019s customer directory'],
  orders: ['Orders', 'Track every order from placed to delivered'],
  reports: ['Reports', 'Sales, stock, and performance at a glance'],
  'plant-care': ['Plant Care Management', 'Watering, fertilizer, sunlight and care notes'],
  catalog: ['Plant Catalog', 'Browse what\u2019s in season and add to cart'],
  cart: ['Your Cart', 'Review before checkout'],
  profile: ['Profile', 'Manage your account'],
  login: ['Welcome', 'Log in or create an account'],
}

export default function Header({ view, setView }) {
  const { theme, currentUser } = useAppState()
  const dispatch = useAppDispatch()
  const [permission, setPermission] = useState(
    typeof Notification !== 'undefined' ? Notification.permission : 'unsupported'
  )

  useEffect(() => {
    if (typeof Notification !== 'undefined') setPermission(Notification.permission)
  }, [])

  const [title, subtitle] = TITLES[view] || TITLES.catalog

  async function handleEnableNotifications() {
    const result = await requestNotificationPermission()
    setPermission(result)
  }

  function handleLogout() {
    dispatch({ type: 'LOGOUT' })
    setView('catalog')
  }

  return (
    <header className="flex items-start justify-between gap-4 px-6 md:px-10 pt-8 pb-6">
      <div>
        <h1 className="font-display text-3xl md:text-4xl text-forest dark:text-sage-light">
          {title}
        </h1>
        <p className="text-[var(--text-muted)] text-sm mt-1">{subtitle}</p>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        {permission !== 'granted' && permission !== 'unsupported' && (
          <button
            onClick={handleEnableNotifications}
            className="focus-ring hidden sm:inline-block text-xs px-3 py-2 rounded-md border border-[var(--border)] text-[var(--text-muted)] hover:border-clay hover:text-clay transition-colors"
          >
            Enable order alerts
          </button>
        )}
        <button
          aria-label="Toggle theme"
          onClick={() => dispatch({ type: 'TOGGLE_THEME' })}
          className="focus-ring w-9 h-9 rounded-full border border-[var(--border)] flex items-center justify-center hover:border-clay transition-colors"
        >
          {theme === 'light' ? <MoonIcon /> : <SunFilledIcon />}
        </button>

        {currentUser ? (
          <div className="flex items-center gap-2 pl-2 ml-1 border-l border-[var(--border)]">
            <div className="hidden sm:flex flex-col items-end leading-tight">
              <span className="text-sm font-medium">{currentUser.name}</span>
              <span className="text-[10px] uppercase tracking-wide text-[var(--text-muted)]">
                {currentUser.role === 'admin' ? 'Nursery staff' : 'Customer'}
              </span>
            </div>
            <div className="w-9 h-9 rounded-full bg-forest text-linen dark:bg-sage-light dark:text-forest-dark flex items-center justify-center text-sm font-medium">
              {currentUser.name.charAt(0).toUpperCase()}
            </div>
            <button
              onClick={handleLogout}
              aria-label="Log out"
              className="focus-ring w-9 h-9 rounded-full border border-[var(--border)] flex items-center justify-center hover:border-clay hover:text-clay transition-colors"
            >
              <LogoutIcon />
            </button>
          </div>
        ) : (
          <button
            onClick={() => setView('login')}
            className="focus-ring flex items-center gap-1.5 text-sm px-3 py-2 rounded-sm border border-[var(--border)] hover:border-clay hover:text-clay transition-colors"
          >
            <UserIcon className="w-4 h-4" /> Log in
          </button>
        )}
      </div>
    </header>
  )
}
