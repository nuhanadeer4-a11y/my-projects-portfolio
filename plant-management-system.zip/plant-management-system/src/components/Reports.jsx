import React, { useMemo } from 'react'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  LineChart, Line,
} from 'recharts'
import { useAppState } from '../context/AppContext.jsx'
import { formatLKR } from '../utils/currency.js'

export default function Reports() {
  const { orders, plants } = useAppState()

  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0)
  const totalSold = orders.reduce(
    (sum, o) => sum + o.items.reduce((s, i) => s + i.qty, 0),
    0
  )

  const mostSold = useMemo(() => {
    const map = {}
    orders.forEach((o) => o.items.forEach((i) => { map[i.name] = (map[i.name] || 0) + i.qty }))
    return Object.entries(map).map(([name, qty]) => ({ name, qty })).sort((a, b) => b.qty - a.qty).slice(0, 8)
  }, [orders])

  const lowStock = plants.filter((p) => p.stock <= p.lowStockAt)

  const monthlySales = useMemo(() => {
    const map = {}
    orders.forEach((o) => {
      const d = new Date(o.placedAt)
      const key = d.toLocaleString('en-LK', { month: 'short', year: '2-digit' })
      map[key] = (map[key] || 0) + o.total
    })
    return Object.entries(map).map(([month, total]) => ({ month, total }))
  }, [orders])

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12 space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total revenue" value={formatLKR(totalRevenue)} />
        <StatCard label="Plants sold" value={totalSold} />
        <StatCard label="Orders placed" value={orders.length} />
        <StatCard label="Low-stock plants" value={lowStock.length} />
      </div>

      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
        <h3 className="font-display text-lg mb-4">Monthly sales</h3>
        {monthlySales.length === 0 ? (
          <p className="text-sm text-[var(--text-muted)]">No sales recorded yet.</p>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={monthlySales}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" stroke="var(--text-muted)" fontSize={12} />
              <YAxis stroke="var(--text-muted)" fontSize={12} />
              <Tooltip
                formatter={(v) => formatLKR(v)}
                contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', fontSize: 12 }}
              />
              <Line type="monotone" dataKey="total" stroke="#B5622E" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
          <h3 className="font-display text-lg mb-4">Most sold plants</h3>
          {mostSold.length === 0 ? (
            <p className="text-sm text-[var(--text-muted)]">No sales recorded yet.</p>
          ) : (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={mostSold} layout="vertical" margin={{ left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="var(--border)" />
                <XAxis type="number" allowDecimals={false} stroke="var(--text-muted)" fontSize={12} />
                <YAxis type="category" dataKey="name" width={90} stroke="var(--text-muted)" fontSize={12} />
                <Tooltip contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', fontSize: 12 }} />
                <Bar dataKey="qty" fill="#1F3D2B" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
          <h3 className="font-display text-lg mb-4">Low-stock report</h3>
          {lowStock.length === 0 ? (
            <p className="text-sm text-[var(--text-muted)]">Everything is well-stocked 🌿</p>
          ) : (
            <ul className="divide-y divide-[var(--border)] text-sm">
              {lowStock.map((p) => (
                <li key={p.id} className="flex items-center justify-between py-2">
                  <span>{p.name}</span>
                  <span className="text-amber font-medium">{p.stock} left</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
        <h3 className="font-display text-lg mb-4">Stock report — all plants</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-[var(--text-muted)] border-b border-[var(--border)]">
              <th className="p-2">Plant</th>
              <th className="p-2">Category</th>
              <th className="p-2">Price</th>
              <th className="p-2">Stock</th>
            </tr>
          </thead>
          <tbody>
            {plants.map((p) => (
              <tr key={p.id} className="border-b border-[var(--border)] last:border-0">
                <td className="p-2">{p.name}</td>
                <td className="p-2 text-[var(--text-muted)]">{p.category}</td>
                <td className="p-2">{formatLKR(p.price)}</td>
                <td className="p-2">{p.stock}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function StatCard({ label, value }) {
  return (
    <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-4">
      <p className="text-xs text-[var(--text-muted)] mb-1">{label}</p>
      <p className="font-display text-2xl text-forest dark:text-sage-light">{value}</p>
    </div>
  )
}
