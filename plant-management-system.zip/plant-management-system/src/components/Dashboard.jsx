import React, { useMemo } from 'react'
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from 'recharts'
import { useAppState } from '../context/AppContext.jsx'
import { formatLKR } from '../utils/currency.js'
import { LeafIcon, PotIcon, BoxIcon, AlertIcon } from './icons.jsx'

export default function Dashboard() {
  const { orders, plants, categories } = useAppState()

  const totalPlants = plants.length
  const totalCategories = categories.length
  const plantsSold = orders.reduce((sum, o) => sum + o.items.reduce((s, i) => s + i.qty, 0), 0)
  const lowStockPlants = plants.filter((p) => p.stock <= p.lowStockAt)
  const recentOrders = orders.slice(0, 5)

  const salesTrend = useMemo(() => {
    const map = {}
    orders.forEach((o) => {
      const key = new Date(o.placedAt).toLocaleDateString('en-LK', { day: '2-digit', month: 'short' })
      map[key] = (map[key] || 0) + o.total
    })
    return Object.entries(map).map(([date, total]) => ({ date, total })).slice(-14)
  }, [orders])

  return (
    <div className="px-6 md:px-10 pb-24 md:pb-12 space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total plants" value={totalPlants} icon={<LeafIcon className="w-4 h-4" />} />
        <StatCard label="Total categories" value={totalCategories} icon={<PotIcon className="w-4 h-4" />} />
        <StatCard label="Plants sold" value={plantsSold} icon={<BoxIcon className="w-4 h-4" />} />
        <StatCard
          label="Low stock plants"
          value={lowStockPlants.length}
          icon={<AlertIcon className="w-4 h-4" />}
          warn={lowStockPlants.length > 0}
        />
      </div>

      <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
        <h3 className="font-display text-lg mb-4">Sales summary</h3>
        {salesTrend.length === 0 ? (
          <p className="text-sm text-[var(--text-muted)]">Sales will appear here once orders come in.</p>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={salesTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="date" stroke="var(--text-muted)" fontSize={12} />
              <YAxis stroke="var(--text-muted)" fontSize={12} />
              <Tooltip
                formatter={(v) => formatLKR(v)}
                contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)', fontSize: 12 }}
              />
              <Line type="monotone" dataKey="total" stroke="#1F3D2B" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
          <h3 className="font-display text-lg mb-4">Recent orders</h3>
          {recentOrders.length === 0 ? (
            <p className="text-sm text-[var(--text-muted)]">No orders yet.</p>
          ) : (
            <ul className="divide-y divide-[var(--border)] text-sm">
              {recentOrders.map((o) => (
                <li key={o.id} className="flex items-center justify-between py-2.5">
                  <div>
                    <p className="font-medium">{o.id}</p>
                    <p className="text-xs text-[var(--text-muted)]">{o.customer.name} · {o.status}</p>
                  </div>
                  <span className="font-display text-forest dark:text-sage-light">{formatLKR(o.total)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="border border-[var(--border)] rounded-sm bg-[var(--surface)] p-5">
          <h3 className="font-display text-lg mb-4">Low-stock plants</h3>
          {lowStockPlants.length === 0 ? (
            <p className="text-sm text-[var(--text-muted)]">Everything is well-stocked 🌿</p>
          ) : (
            <ul className="divide-y divide-[var(--border)] text-sm">
              {lowStockPlants.map((p) => (
                <li key={p.id} className="flex items-center justify-between py-2.5">
                  <span>{p.name}</span>
                  <span className="text-amber font-medium">{p.stock} left</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  )
}

function StatCard({ label, value, icon, warn }) {
  return (
    <div className={`border rounded-sm bg-[var(--surface)] p-4 ${warn ? 'border-amber/50' : 'border-[var(--border)]'}`}>
      <div className="flex items-center gap-1.5 text-xs text-[var(--text-muted)] mb-1">
        {icon}
        {label}
      </div>
      <p className={`font-display text-2xl ${warn ? 'text-amber' : 'text-forest dark:text-sage-light'}`}>{value}</p>
    </div>
  )
}
