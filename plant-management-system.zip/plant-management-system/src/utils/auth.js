// ─────────────────────────────────────────────────────────────────────────
// Auth utilities
//
// IMPORTANT: This project has no backend/server, so there is nowhere secure
// to verify a password. The "hashing" below is a simple, reversible-looking
// obfuscation just so plaintext passwords aren't sitting in localStorage
// as-is during the demo — it is NOT cryptographically secure and must
// NEVER be used in a real production app.
//
// Going to production:
//   Replace everything in this file with real calls to your backend's
//   /signup and /login endpoints, which should hash passwords with
//   bcrypt/argon2 server-side and return a session token (JWT) or set
//   an httpOnly cookie. Services like Supabase Auth, Firebase Auth, or
//   Clerk can do this for you with almost no backend code of your own.
// ─────────────────────────────────────────────────────────────────────────

export function hashPassword(plain) {
  // djb2-style string hash — fast, deterministic, NOT secure.
  let hash = 5381
  for (let i = 0; i < plain.length; i++) {
    hash = (hash * 33) ^ plain.charCodeAt(i)
  }
  return 'demo_' + (hash >>> 0).toString(16)
}

export function isValidEmail(value) {
  return /^\S+@\S+\.\S+$/.test(value)
}

export function isValidPhone(value) {
  return /^\d{10}$/.test(value.replace(/\D/g, ''))
}
