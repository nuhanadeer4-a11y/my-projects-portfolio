// ─────────────────────────────────────────────────────────────────────────
// Payment Gateway
//
// This is a SIMULATED payment processor so the checkout flow works
// end-to-end with zero setup or API keys. It validates card/UPI input
// properly and "processes" with a realistic delay, but no real money
// moves and nothing is sent over the network.
//
// Going live with a real gateway (Razorpay is the standard choice for
// Indian rupee payments):
//   1. Your backend creates an "order" via Razorpay's Orders API and
//      returns an order_id to the frontend (this step MUST happen on
//      a server — your API secret can never be in browser code).
//   2. Frontend loads Razorpay's checkout.js and opens their payment
//      sheet using that order_id (this replaces processCardPayment
//      and processUpiPayment below).
//   3. Razorpay calls your backend webhook to confirm payment; your
//      backend verifies the signature before marking the order paid.
// Stripe, PayU, and Cashfree all follow the same create-order-on-
// server → open-checkout-on-client → verify-on-webhook pattern.
// ─────────────────────────────────────────────────────────────────────────

const SIMULATED_NETWORK_DELAY = 1400

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

export function detectCardBrand(cardNumber) {
  const digits = cardNumber.replace(/\D/g, '')
  if (/^4/.test(digits)) return 'Visa'
  if (/^5[1-5]/.test(digits)) return 'Mastercard'
  if (/^6/.test(digits)) return 'RuPay'
  if (/^3[47]/.test(digits)) return 'Amex'
  return 'Card'
}

export function formatCardNumber(value) {
  const digits = value.replace(/\D/g, '').slice(0, 16)
  return digits.replace(/(\d{4})(?=\d)/g, '$1 ')
}

export function formatExpiry(value) {
  const digits = value.replace(/\D/g, '').slice(0, 4)
  if (digits.length <= 2) return digits
  return `${digits.slice(0, 2)}/${digits.slice(2)}`
}

export function validateCard({ number, expiry, cvv, name }) {
  const errors = {}
  const digits = number.replace(/\D/g, '')
  if (digits.length < 15 || digits.length > 16) errors.number = 'Enter a valid card number'
  if (!/^\d{2}\/\d{2}$/.test(expiry)) {
    errors.expiry = 'Use MM/YY format'
  } else {
    const [mm, yy] = expiry.split('/').map(Number)
    const now = new Date()
    const currentYY = now.getFullYear() % 100
    const currentMM = now.getMonth() + 1
    if (mm < 1 || mm > 12) errors.expiry = 'Invalid month'
    else if (yy < currentYY || (yy === currentYY && mm < currentMM)) errors.expiry = 'Card has expired'
  }
  if (!/^\d{3,4}$/.test(cvv)) errors.cvv = 'Enter a valid CVV'
  if (!name.trim()) errors.name = 'Enter the name on card'
  return errors
}

export function isValidUpiId(value) {
  return /^[\w.\-]{2,}@[a-zA-Z]{2,}$/.test(value.trim())
}

function generateTransactionId() {
  return 'TXN' + Date.now().toString().slice(-8) + Math.random().toString(36).slice(2, 5).toUpperCase()
}

export async function processCardPayment({ amount, card }) {
  await delay(SIMULATED_NETWORK_DELAY)
  return {
    method: 'card',
    brand: detectCardBrand(card.number),
    last4: card.number.replace(/\D/g, '').slice(-4),
    amount,
    status: 'success',
    transactionId: generateTransactionId(),
    paidAt: new Date().toISOString(),
  }
}

export async function processUpiPayment({ amount, upiId }) {
  await delay(SIMULATED_NETWORK_DELAY)
  return {
    method: 'upi',
    upiId,
    amount,
    status: 'success',
    transactionId: generateTransactionId(),
    paidAt: new Date().toISOString(),
  }
}

export async function processCashOnDelivery({ amount }) {
  await delay(400)
  return {
    method: 'cod',
    amount,
    status: 'pending_collection',
    transactionId: generateTransactionId(),
    paidAt: new Date().toISOString(),
  }
}
