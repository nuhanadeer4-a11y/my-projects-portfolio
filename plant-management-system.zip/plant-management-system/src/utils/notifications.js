// ─────────────────────────────────────────────────────────────────────────
// Notification Gateway
//
// Rule requested by the client: when an order is placed, notify the
// customer by EMAIL if they gave one. If they did NOT give an email,
// fall back to an SMS to their phone number instead.
//
// This file is deliberately isolated from the UI so the *simulated*
// senders below can be swapped for real providers without touching
// any component:
//
//   sendEmail()  -> replace body with an EmailJS / Resend / SES call
//   sendSMS()    -> replace body with a call to YOUR OWN backend, which
//                   then calls Twilio / MSG91 / Fast2SMS server-side
//                   (SMS providers reject direct browser calls for
//                   security — you cannot call Twilio from the browser).
//
// See README.md → "Going live with real Email & SMS" for exact steps.
// ─────────────────────────────────────────────────────────────────────────

import { formatLKR } from './currency.js'

const SIMULATED_NETWORK_DELAY = 900

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

/**
 * Simulated email send. Swap this for a real EmailJS call, e.g.:
 *
 *   import emailjs from '@emailjs/browser'
 *   await emailjs.send(SERVICE_ID, TEMPLATE_ID, params, PUBLIC_KEY)
 */
async function sendEmail({ to, subject, body }) {
  await delay(SIMULATED_NETWORK_DELAY)
  console.info('[EMAIL SENT]', { to, subject, body })
  return {
    channel: 'email',
    to,
    subject,
    body,
    status: 'delivered',
    sentAt: new Date().toISOString(),
  }
}

/**
 * Simulated SMS send. Real SMS gateways (Twilio, MSG91, Fast2SMS) must be
 * called from a server, not the browser, so this stays simulated until
 * you wire up a backend endpoint that this function can POST to.
 */
async function sendSMS({ to, body }) {
  await delay(SIMULATED_NETWORK_DELAY)
  console.info('[SMS SENT]', { to, body })
  return {
    channel: 'sms',
    to,
    body,
    status: 'delivered',
    sentAt: new Date().toISOString(),
  }
}

/**
 * Fires a real browser desktop notification (Notification API) in
 * addition to the simulated email/SMS above — this part is NOT
 * simulated, it's a genuine OS-level notification when permission
 * has been granted.
 */
export function fireBrowserNotification(title, options) {
  if (!('Notification' in window)) return
  if (Notification.permission === 'granted') {
    new Notification(title, options)
  }
}

export async function requestNotificationPermission() {
  if (!('Notification' in window)) return 'unsupported'
  if (Notification.permission === 'default') {
    return Notification.requestPermission()
  }
  return Notification.permission
}

/**
 * Core routing rule: EMAIL first, SMS fallback.
 * Returns a log entry describing exactly what was sent and why.
 */
export async function notifyCustomerOfOrder(order) {
  const { customer, id, items, total } = order
  const itemLines = items.map((i) => `${i.name} x${i.qty}`).join(', ')

  if (customer.email && customer.email.trim().length > 0) {
    const result = await sendEmail({
      to: customer.email,
      subject: `Order ${id} confirmed — Thottam Nursery`,
      body: `Hi ${customer.name}, your order (${itemLines}) totaling ${formatLKR(total)} is confirmed. We'll notify you when it ships.`,
    })
    fireBrowserNotification('Order confirmed ✓', {
      body: `Email sent to ${customer.email}`,
    })
    return { ...result, reason: 'Email address was provided' }
  }

  const result = await sendSMS({
    to: customer.phone,
    body: `Thottam Nursery: Order ${id} confirmed (${itemLines}) - ${formatLKR(total)}. Thank you!`,
  })
  fireBrowserNotification('Order confirmed ✓', {
    body: `SMS sent to ${customer.phone}`,
  })
  return { ...result, reason: 'No email given — fell back to SMS' }
}
