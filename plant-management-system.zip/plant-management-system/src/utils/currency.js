// Sri Lankan Rupee formatting helper used across the whole app.
export function formatLKR(amount) {
  const n = Number(amount) || 0
  return 'Rs. ' + n.toLocaleString('en-LK')
}
