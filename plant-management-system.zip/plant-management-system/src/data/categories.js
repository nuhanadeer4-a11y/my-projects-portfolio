export const initialCategories = [
  { id: 'CAT-01', name: 'Indoor Plants' },
  { id: 'CAT-02', name: 'Outdoor Plants' },
  { id: 'CAT-03', name: 'Flowering Plants' },
  { id: 'CAT-04', name: 'Medicinal Plants' },
  { id: 'CAT-05', name: 'Succulents' },
]
