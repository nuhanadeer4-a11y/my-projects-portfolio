import React, { createContext, useContext, useEffect, useReducer } from 'react'
import { initialPlants } from '../data/plants.js'
import { initialCategories } from '../data/categories.js'
import { hashPassword } from '../utils/auth.js'

const STORAGE_KEY = 'thottam-plant-system-v5'

// Seeded so the "Fill demo admin credentials" button on the login screen
// works immediately without signing up first.
const seedUsers = [
  {
    id: 'USR-DEMO01',
    name: 'Nursery Admin',
    email: 'demo@thottam.com',
    phone: '0771234567',
    role: 'admin',
    passwordHash: hashPassword('demo123'),
    joinedAt: new Date().toISOString(),
  },
]

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return JSON.parse(raw)
  } catch (e) {
    console.warn('Could not load saved state', e)
  }
  return null
}

const defaultState = {
  plants: initialPlants,
  categories: initialCategories,
  cart: [],
  orders: [],
  notificationLog: [],
  stockHistory: [],
  customers: [],
  theme: 'light',
  users: seedUsers,
  currentUser: null,
}

function reducer(state, action) {
  switch (action.type) {
    case 'SIGNUP': {
      const users = [...state.users, action.user]
      const { passwordHash, ...publicUser } = action.user
      return { ...state, users, currentUser: publicUser }
    }
    case 'LOGIN': {
      const { passwordHash, ...publicUser } = action.user
      return { ...state, currentUser: publicUser }
    }
    case 'LOGOUT':
      return { ...state, currentUser: null }
    case 'UPDATE_PROFILE': {
      const users = state.users.map((u) =>
        u.id === action.userId ? { ...u, ...action.changes } : u
      )
      return {
        ...state,
        users,
        currentUser: state.currentUser
          ? { ...state.currentUser, ...action.changes }
          : state.currentUser,
      }
    }
    case 'CHANGE_PASSWORD': {
      const users = state.users.map((u) =>
        u.id === action.userId ? { ...u, passwordHash: action.passwordHash } : u
      )
      return { ...state, users }
    }
    case 'ADD_TO_CART': {
      const existing = state.cart.find((c) => c.id === action.plant.id)
      const cart = existing
        ? state.cart.map((c) =>
            c.id === action.plant.id ? { ...c, qty: c.qty + 1 } : c
          )
        : [...state.cart, { ...action.plant, qty: 1 }]
      return { ...state, cart }
    }
    case 'DECREASE_QTY': {
      const cart = state.cart
        .map((c) => (c.id === action.id ? { ...c, qty: c.qty - 1 } : c))
        .filter((c) => c.qty > 0)
      return { ...state, cart }
    }
    case 'REMOVE_FROM_CART':
      return { ...state, cart: state.cart.filter((c) => c.id !== action.id) }
    case 'CLEAR_CART':
      return { ...state, cart: [] }
    case 'PLACE_ORDER': {
      const plants = state.plants.map((p) => {
        const inCart = action.order.items.find((i) => i.id === p.id)
        if (!inCart) return p
        return { ...p, stock: Math.max(0, p.stock - inCart.qty) }
      })
      return {
        ...state,
        plants,
        cart: [],
        orders: [action.order, ...state.orders],
      }
    }
    case 'UPDATE_ORDER_STATUS':
      return {
        ...state,
        orders: state.orders.map((o) =>
          o.id === action.id ? { ...o, status: action.status } : o
        ),
      }
    case 'LOG_NOTIFICATION':
      return {
        ...state,
        notificationLog: [action.entry, ...state.notificationLog].slice(0, 50),
      }
    case 'ADD_PLANT':
      return { ...state, plants: [action.plant, ...state.plants] }
    case 'UPDATE_PLANT':
      return {
        ...state,
        plants: state.plants.map((p) =>
          p.id === action.plant.id ? action.plant : p
        ),
      }
    case 'DELETE_PLANT':
      return { ...state, plants: state.plants.filter((p) => p.id !== action.id) }
    case 'ADJUST_STOCK': {
      // action: { plantId, delta, reason }
      const plants = state.plants.map((p) =>
        p.id === action.plantId
          ? { ...p, stock: Math.max(0, p.stock + action.delta) }
          : p
      )
      const plant = state.plants.find((p) => p.id === action.plantId)
      const entry = {
        id: 'STK-' + Date.now().toString().slice(-8),
        plantId: action.plantId,
        plantName: plant?.name || action.plantId,
        delta: action.delta,
        reason: action.reason,
        at: new Date().toISOString(),
      }
      return {
        ...state,
        plants,
        stockHistory: [entry, ...state.stockHistory].slice(0, 100),
      }
    }
    case 'ADD_CATEGORY':
      return { ...state, categories: [...state.categories, action.category] }
    case 'UPDATE_CATEGORY':
      return {
        ...state,
        categories: state.categories.map((c) =>
          c.id === action.category.id ? action.category : c
        ),
      }
    case 'DELETE_CATEGORY':
      return {
        ...state,
        categories: state.categories.filter((c) => c.id !== action.id),
      }
    case 'ADD_CUSTOMER':
      return { ...state, customers: [action.customer, ...state.customers] }
    case 'UPDATE_CUSTOMER':
      return {
        ...state,
        customers: state.customers.map((c) =>
          c.id === action.customer.id ? action.customer : c
        ),
      }
    case 'DELETE_CUSTOMER':
      return {
        ...state,
        customers: state.customers.filter((c) => c.id !== action.id),
      }
    case 'TOGGLE_THEME':
      return { ...state, theme: state.theme === 'light' ? 'dark' : 'light' }
    case 'HYDRATE':
      return { ...state, ...action.payload }
    default:
      return state
  }
}

const AppStateContext = createContext(null)
const AppDispatchContext = createContext(null)

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, defaultState, () => {
    const saved = loadState()
    return saved ? { ...defaultState, ...saved } : defaultState
  })

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  }, [state])

  useEffect(() => {
    document.documentElement.classList.toggle('dark', state.theme === 'dark')
  }, [state.theme])

  return (
    <AppStateContext.Provider value={state}>
      <AppDispatchContext.Provider value={dispatch}>
        {children}
      </AppDispatchContext.Provider>
    </AppStateContext.Provider>
  )
}

export function useAppState() {
  const ctx = useContext(AppStateContext)
  if (!ctx) throw new Error('useAppState must be used within AppProvider')
  return ctx
}

export function useAppDispatch() {
  const ctx = useContext(AppDispatchContext)
  if (!ctx) throw new Error('useAppDispatch must be used within AppProvider')
  return ctx
}
