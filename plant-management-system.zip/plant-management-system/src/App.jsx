import React, { useState } from 'react'
import Sidebar from './components/Sidebar.jsx'
import MobileNav from './components/MobileNav.jsx'
import Header from './components/Header.jsx'
import PlantCatalog from './components/PlantCatalog.jsx'
import Cart from './components/Cart.jsx'
import OrdersList from './components/OrdersList.jsx'
import Plants from './components/Plants.jsx'
import Categories from './components/Categories.jsx'
import Inventory from './components/Inventory.jsx'
import Customers from './components/Customers.jsx'
import PlantCare from './components/PlantCare.jsx'
import Reports from './components/Reports.jsx'
import Dashboard from './components/Dashboard.jsx'
import Profile from './components/Profile.jsx'
import Auth from './components/Auth.jsx'
import PublicNav from './components/public/PublicNav.jsx'
import PublicFooter from './components/public/PublicFooter.jsx'
import Home from './components/public/Home.jsx'
import About from './components/public/About.jsx'
import Contact from './components/public/Contact.jsx'
import { useAppState } from './context/AppContext.jsx'

const ADMIN_ONLY_VIEWS = ['dashboard', 'plants', 'categories', 'inventory', 'customers', 'reports', 'plant-care']

export default function App() {
  const { currentUser } = useAppState()

  // Public marketing site: Home / About / Contact Us / Login.
  const [guestView, setGuestView] = useState('home')

  // The logged-in app (Dashboard for admin, Catalog for customer, etc).
  const [view, setView] = useState('')

  // ── Not logged in: show the public website ──────────────────────────
  if (!currentUser) {
    if (guestView === 'login') {
      return <Auth onSuccess={() => setGuestView('home')} />
    }
    return (
      <div className="min-h-screen flex flex-col bg-[var(--bg)]">
        <PublicNav view={guestView} setView={setGuestView} />
        <main className="flex-1">
          {guestView === 'home' && <Home setView={setGuestView} />}
          {guestView === 'about' && <About />}
          {guestView === 'contact' && <Contact />}
        </main>
        <PublicFooter setView={setGuestView} />
      </div>
    )
  }

  // ── Logged in: the full management / shopping app ───────────────────
  const isAdmin = currentUser.role === 'admin'
  const defaultView = isAdmin ? 'dashboard' : 'catalog'
  const activeView = view || defaultView
  const blockedForRole = ADMIN_ONLY_VIEWS.includes(activeView) && !isAdmin
  const effectiveView = blockedForRole ? defaultView : activeView

  return (
    <div className="min-h-screen flex bg-[var(--bg)]">
      <Sidebar view={effectiveView} setView={setView} />
      <main className="flex-1 min-w-0">
        <Header view={effectiveView} setView={setView} />
        {effectiveView === 'dashboard' && <Dashboard />}
        {effectiveView === 'plants' && <Plants />}
        {effectiveView === 'categories' && <Categories />}
        {effectiveView === 'inventory' && <Inventory />}
        {effectiveView === 'customers' && <Customers />}
        {effectiveView === 'reports' && <Reports />}
        {effectiveView === 'plant-care' && <PlantCare />}
        {effectiveView === 'orders' && <OrdersList />}
        {effectiveView === 'catalog' && <PlantCatalog />}
        {effectiveView === 'cart' && <Cart />}
        {effectiveView === 'profile' && <Profile setView={setView} />}
      </main>
      <MobileNav view={effectiveView} setView={setView} />
    </div>
  )
}
