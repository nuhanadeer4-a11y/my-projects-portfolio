/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        body: ['"Work Sans"', 'sans-serif'],
      },
      colors: {
        linen: '#F7F5EF',
        forest: {
          DEFAULT: '#1F3D2B',
          light: '#2C543C',
          dark: '#122318',
        },
        clay: {
          DEFAULT: '#B5622E',
          light: '#D08554',
          dark: '#8A4A22',
        },
        sage: {
          DEFAULT: '#8FA787',
          light: '#B7C7B0',
        },
        charcoal: '#24261F',
        amber: '#C99A3C',
        rose: '#A6413A',
      },
      boxShadow: {
        card: '0 2px 0 0 rgba(31, 61, 43, 0.15)',
      },
    },
  },
  plugins: [],
}
