<?php
require_once '../includes/config.php';
requireRole('admin', '../login.php');
$pageTitle = 'Manage Products';
$basePath  = '../';

if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM products WHERE id=".(int)$_GET['delete']);
    setFlash('success', 'Product deleted.'); redirect('products.php');
}

if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $p  = $conn->query("SELECT status FROM products WHERE id=$id")->fetch_assoc();
    $newStatus = ($p['status'] === 'available') ? 'out_of_stock' : 'available';
    $conn->query("UPDATE products SET status='$newStatus' WHERE id=$id");
    setFlash('success', 'Status updated.'); redirect('products.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pid   = (int)($_POST['product_id'] ?? 0);
    $name  = clean($conn, $_POST['name']);
    $desc  = clean($conn, $_POST['description']);
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock_quantity'];
    $cat   = clean($conn, $_POST['category']);
    $stat  = clean($conn, $_POST['status']);

    if ($pid) {
        $conn->query("UPDATE products SET name='$name', description='$desc', price=$price, stock_quantity=$stock, category='$cat', status='$stat' WHERE id=$pid");
        setFlash('success', 'Product updated.');
    } else {
        $conn->query("INSERT INTO products (name, description, price, stock_quantity, category, status) VALUES ('$name','$desc',$price,$stock,'$cat','$stat')");
        setFlash('success', 'Product added.');
    }
    redirect('products.php');
}

$editProduct = null;
if (isset($_GET['edit'])) {
    $editProduct = $conn->query("SELECT * FROM products WHERE id=".(int)$_GET['edit'])->fetch_assoc();
}

$products = $conn->query("SELECT p.*, u.full_name AS baker_name FROM products p LEFT JOIN users u ON p.baker_id = u.id ORDER BY p.id DESC");

include '../includes/header.php';
?>

<h1 class="page-title"><i class="fas fa-candy-cane"></i> Manage Products</h1>

<div class="card">
    <h2><?= $editProduct ? 'Edit Product' : 'Add New Product' ?></h2>
    <form method="POST">
        <?php if ($editProduct): ?>
            <input type="hidden" name="product_id" value="<?= $editProduct['id'] ?>">
        <?php endif; ?>
        <div class="form-row">
            <div class="form-group">
                <label>Product Name</label>
                <input type="text" name="name" required value="<?= htmlspecialchars($editProduct['name'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Category</label>
                <select name="category">
                    <?php foreach (['Cakes','Cupcakes','Macarons','Cookies','Traditional','Other'] as $cat): ?>
                        <option <?= (($editProduct['category'] ?? '') === $cat) ? 'selected' : '' ?>><?= $cat ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea name="description"><?= htmlspecialchars($editProduct['description'] ?? '') ?></textarea>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Price (Rs.)</label>
                <input type="number" name="price" step="0.01" min="0" required value="<?= $editProduct['price'] ?? '' ?>">
            </div>
            <div class="form-group">
                <label>Stock Quantity</label>
                <input type="number" name="stock_quantity" min="0" required value="<?= $editProduct['stock_quantity'] ?? 0 ?>">
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="available" <?= (($editProduct['status'] ?? '') === 'available') ? 'selected' : '' ?>>Available</option>
                    <option value="out_of_stock" <?= (($editProduct['status'] ?? '') === 'out_of_stock') ? 'selected' : '' ?>>Out of Stock</option>
                </select>
            </div>
        </div>
        <div style="display:flex;gap:10px;">
            <button type="submit" class="btn btn-primary"><?= $editProduct ? '💾 Update' : '➕ Add Product' ?></button>
            <?php if ($editProduct): ?><a href="products.php" class="btn btn-secondary">Cancel</a><?php endif; ?>
        </div>
    </form>
</div>

<div class="card">
    <h2>All Products</h2>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>#</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Baker</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
                <?php while ($p = $products->fetch_assoc()): ?>
                <tr>
                    <td><?= $p['id'] ?></td>
                    <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
                    <td><?= htmlspecialchars($p['category']) ?></td>
                    <td>Rs. <?= number_format($p['price'], 2) ?></td>
                    <td><span class="badge badge-<?= $p['stock_quantity'] < 5 ? 'danger' : 'success' ?>"><?= $p['stock_quantity'] ?></span></td>
                    <td><?= $p['baker_name'] ? htmlspecialchars($p['baker_name']) : '<em>Admin</em>' ?></td>
                    <td><span class="badge badge-<?= $p['status']==='available'?'success':'danger' ?>"><?= ucfirst(str_replace('_',' ',$p['status'])) ?></span></td>
                    <td style="white-space:nowrap;">
                        <a href="products.php?edit=<?= $p['id'] ?>" class="btn btn-warning btn-sm">✏️ Edit</a>
                        <a href="products.php?toggle=<?= $p['id'] ?>" class="btn btn-info btn-sm">🔄 Toggle</a>
                        <a href="products.php?delete=<?= $p['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete?')">🗑️</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
