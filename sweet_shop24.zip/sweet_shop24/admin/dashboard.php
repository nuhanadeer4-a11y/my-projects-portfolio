<?php
require_once '../includes/config.php';
requireRole('admin', '../login.php');
$pageTitle = 'Admin Dashboard';
$basePath  = '../';

$totalCustomers = $conn->query("SELECT COUNT(*) as c FROM users WHERE role='customer'")->fetch_assoc()['c'];
$totalProducts  = $conn->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
$totalOrders    = $conn->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc()['c'];
$pendingOrders  = $conn->query("SELECT COUNT(*) as c FROM orders WHERE status='pending'")->fetch_assoc()['c'];
$revenue        = $conn->query("SELECT SUM(total_amount) as r FROM orders WHERE status != 'cancelled'")->fetch_assoc()['r'];
$lowStock       = $conn->query("SELECT COUNT(*) as c FROM products WHERE stock_quantity < 5")->fetch_assoc()['c'];

$recentOrders = $conn->query("SELECT o.*, u.full_name AS customer_name FROM orders o JOIN users u ON o.customer_id = u.id ORDER BY o.created_at DESC LIMIT 8");

include '../includes/header.php';
?>

<h1 class="page-title"><i class="fas fa-tachometer-alt"></i> Admin Dashboard</h1>

<!-- Stats -->
<div class="grid-4" style="margin-bottom:30px;">
    <div class="stat-card">
        <div class="stat-icon">👥</div>
        <div class="stat-number"><?= $totalCustomers ?></div>
        <div class="stat-label">Customers</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">🍰</div>
        <div class="stat-number"><?= $totalProducts ?></div>
        <div class="stat-label">Products</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">📦</div>
        <div class="stat-number"><?= $totalOrders ?></div>
        <div class="stat-label">Total Orders</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">⏳</div>
        <div class="stat-number"><?= $pendingOrders ?></div>
        <div class="stat-label">Pending Orders</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">💰</div>
        <div class="stat-number">Rs. <?= number_format($revenue ?? 0) ?></div>
        <div class="stat-label">Total Revenue</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">⚠️</div>
        <div class="stat-number"><?= $lowStock ?></div>
        <div class="stat-label">Low Stock Items</div>
    </div>
</div>

<!-- Quick Links -->
<div class="grid-4" style="margin-bottom:30px;">
    <a href="products.php"  class="btn btn-primary"><i class="fas fa-candy-cane"></i> Products</a>
    <a href="orders.php"    class="btn btn-info"><i class="fas fa-list"></i> Orders</a>
    <a href="users.php"     class="btn btn-success"><i class="fas fa-users"></i> Users</a>
    <a href="inventory.php" class="btn btn-warning"><i class="fas fa-boxes"></i> Inventory</a>
</div>

<!-- Recent Orders -->
<div class="card">
    <div class="flex-between mb-20">
        <h2>Recent Orders</h2>
        <a href="orders.php" class="btn btn-secondary btn-sm">View All</a>
    </div>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>#Order</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($o = $recentOrders->fetch_assoc()): ?>
                <?php
                $badgeMap = [
                    'pending'   => 'warning',
                    'confirmed' => 'info',
                    'preparing' => 'info',
                    'ready'     => 'success',
                    'delivered' => 'success',
                    'cancelled' => 'danger'
                ];
                ?>
                <tr>
                    <td><strong>#<?= $o['id'] ?></strong></td>
                    <td><?= htmlspecialchars($o['customer_name']) ?></td>
                    <td>Rs. <?= number_format($o['total_amount'], 2) ?></td>
                    <td>
                        <span class="badge badge-<?= $badgeMap[$o['status']] ?? 'secondary' ?>">
                            <?= ucfirst($o['status']) ?>
                        </span>
                    </td>
                    <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                    <td>
                        <a href="order_detail.php?id=<?= $o['id'] ?>" class="btn btn-info btn-sm">
                            👁 View
                        </a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>