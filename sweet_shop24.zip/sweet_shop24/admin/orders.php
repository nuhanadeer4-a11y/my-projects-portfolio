<?php
require_once '../includes/config.php';
requireRole('admin', '../login.php');
$pageTitle = 'Manage Orders';
$basePath  = '../';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $oid    = (int)$_POST['order_id'];
    $status = clean($conn, $_POST['status']);
    $conn->query("UPDATE orders SET status='$status' WHERE id=$oid");
    setFlash('success', "Order #$oid updated to $status.");
    redirect('orders.php');
}

$filter = clean($conn, $_GET['status'] ?? '');
$where  = $filter ? "WHERE o.status='$filter'" : '';
$orders = $conn->query("SELECT o.*, u.full_name AS customer_name, u.email AS customer_email FROM orders o JOIN users u ON o.customer_id = u.id $where ORDER BY o.created_at DESC");

include '../includes/header.php';
?>

<h1 class="page-title"><i class="fas fa-list"></i> Manage Orders</h1>

<div class="card" style="padding:14px;">
    <strong>Filter:</strong>
    <?php foreach ([''=>'All','pending'=>'Pending','confirmed'=>'Confirmed','preparing'=>'Preparing','ready'=>'Ready','delivered'=>'Delivered','cancelled'=>'Cancelled'] as $k=>$label): ?>
        <a href="orders.php<?= $k ? '?status='.$k : '' ?>" class="btn btn-sm <?= $filter===$k?'btn-primary':'btn-secondary' ?>" style="margin:3px"><?= $label ?></a>
    <?php endforeach; ?>
</div>

<div class="card">
    <div class="table-wrapper">
        <table>
            <thead><tr><th>#</th><th>Customer</th><th>Email</th><th>Amount</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
            <tbody>
                <?php while ($o = $orders->fetch_assoc()): ?>
                <?php $badgeMap = ['pending'=>'warning','confirmed'=>'info','preparing'=>'info','ready'=>'success','delivered'=>'success','cancelled'=>'danger']; ?>
                <tr>
                    <td><strong>#<?= $o['id'] ?></strong></td>
                    <td><?= htmlspecialchars($o['customer_name']) ?></td>
                    <td><?= htmlspecialchars($o['customer_email']) ?></td>
                    <td>Rs. <?= number_format($o['total_amount'], 2) ?></td>
                    <td><span class="badge badge-<?= $badgeMap[$o['status']]??'secondary' ?>"><?= ucfirst($o['status']) ?></span></td>
                    <td><?= date('d M Y H:i', strtotime($o['created_at'])) ?></td>
                    <td>
                        <a href="order_detail.php?id=<?= $o['id'] ?>" class="btn btn-info btn-sm">👁 View</a>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                            <select name="status" onchange="this.form.submit()" style="padding:4px 8px;border-radius:6px;border:1px solid #ccc;font-size:.8rem;">
                                <?php foreach (['pending','confirmed','preparing','ready','delivered','cancelled'] as $s): ?>
                                    <option value="<?= $s ?>" <?= $o['status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
