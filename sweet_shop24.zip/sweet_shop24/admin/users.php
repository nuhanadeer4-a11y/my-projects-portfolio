<?php
require_once '../includes/config.php';
requireRole('admin', '../login.php');
$pageTitle = 'Manage Users';
$basePath  = '../';

if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $u  = $conn->query("SELECT status FROM users WHERE id=$id")->fetch_assoc();
    $new = ($u['status'] === 'active') ? 'suspended' : 'active';
    $conn->query("UPDATE users SET status='$new' WHERE id=$id");
    setFlash('success', 'User status updated.'); redirect('users.php');
}
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM users WHERE id=".(int)$_GET['delete']." AND role != 'admin'");
    setFlash('success', 'User deleted.'); redirect('users.php');
}

$roleFilter = clean($conn, $_GET['role'] ?? '');
$where = $roleFilter ? "WHERE role='$roleFilter'" : '';
$users = $conn->query("SELECT * FROM users $where ORDER BY created_at DESC");

include '../includes/header.php';
?>

<h1 class="page-title"><i class="fas fa-users"></i> Manage Users</h1>

<!-- Filter -->
<div class="card" style="padding:14px;">
    <strong>Filter:</strong>
    <?php foreach ([''=>'All','customer'=>'Customers','admin'=>'Admins'] as $k=>$label): ?>
        <a href="users.php<?= $k?'?role='.$k:'' ?>"
           class="btn btn-sm <?= $roleFilter===$k?'btn-primary':'btn-secondary' ?>"
           style="margin:3px"><?= $label ?>
        </a>
    <?php endforeach; ?>
</div>

<!-- All Users -->
<div class="card">
    <h2>All Users</h2>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Joined</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($u = $users->fetch_assoc()): ?>
                <tr>
                    <td><?= $u['id'] ?></td>
                    <td><?= htmlspecialchars($u['full_name']) ?></td>
                    <td><?= htmlspecialchars($u['email']) ?></td>
                    <td>
                        <span class="badge badge-<?= ['admin'=>'danger','baker'=>'warning','customer'=>'info'][$u['role']] ?>">
                            <?= ucfirst($u['role']) ?>
                        </span>
                    </td>
                    <td>
                        <span class="badge badge-<?= $u['status']==='active'?'success':($u['status']==='pending'?'warning':'danger') ?>">
                            <?= ucfirst($u['status']) ?>
                        </span>
                    </td>
                    <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                    <td>
                        <?php if ($u['role'] !== 'admin'): ?>
                            <a href="users.php?toggle=<?= $u['id'] ?>" class="btn btn-warning btn-sm">
                                <?= $u['status']==='active'?'🚫 Suspend':'✅ Activate' ?>
                            </a>
                            <a href="users.php?delete=<?= $u['id'] ?>" class="btn btn-danger btn-sm"
                               onclick="return confirm('Delete this user?')">🗑️</a>
                        <?php else: ?>
                            <em class="text-muted">Protected</em>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>