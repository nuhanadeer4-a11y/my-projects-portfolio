<?php
require_once '../includes/config.php';
requireRole('admin', '../login.php');
$pageTitle = 'Inventory';
$basePath  = '../';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pid   = (int)$_POST['product_id'];
    $stock = (int)$_POST['stock_quantity'];
    $conn->query("UPDATE products SET stock_quantity=$stock, status=IF($stock > 0, 'available', 'out_of_stock') WHERE id=$pid");
    setFlash('success', 'Stock updated.'); redirect('inventory.php');
}

$filter = clean($conn, $_GET['filter'] ?? '');
$where  = '';
if ($filter === 'low')  $where = "WHERE stock_quantity < 5 AND stock_quantity > 0";
if ($filter === 'out')  $where = "WHERE stock_quantity = 0";
if ($filter === 'good') $where = "WHERE stock_quantity >= 5";

$products   = $conn->query("SELECT p.*, u.full_name AS baker_name FROM products p LEFT JOIN users u ON p.baker_id = u.id $where ORDER BY p.stock_quantity ASC");
$totalItems = $conn->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
$outOfStock = $conn->query("SELECT COUNT(*) as c FROM products WHERE stock_quantity=0")->fetch_assoc()['c'];
$lowStock   = $conn->query("SELECT COUNT(*) as c FROM products WHERE stock_quantity < 5 AND stock_quantity > 0")->fetch_assoc()['c'];
$goodStock  = $conn->query("SELECT COUNT(*) as c FROM products WHERE stock_quantity >= 5")->fetch_assoc()['c'];

include '../includes/header.php';
?>

<h1 class="page-title"><i class="fas fa-boxes"></i> Inventory Management</h1>

<div class="grid-4" style="margin-bottom:24px">
    <div class="stat-card"><div class="stat-icon">🍰</div><div class="stat-number"><?= $totalItems ?></div><div class="stat-label">Total Products</div></div>
    <div class="stat-card" style="border-top-color:#27ae60"><div class="stat-icon">✅</div><div class="stat-number" style="color:#27ae60"><?= $goodStock ?></div><div class="stat-label">Well Stocked</div></div>
    <div class="stat-card" style="border-top-color:#e67e22"><div class="stat-icon">⚠️</div><div class="stat-number" style="color:#e67e22"><?= $lowStock ?></div><div class="stat-label">Low Stock</div></div>
    <div class="stat-card" style="border-top-color:#c0392b"><div class="stat-icon">❌</div><div class="stat-number" style="color:#c0392b"><?= $outOfStock ?></div><div class="stat-label">Out of Stock</div></div>
</div>

<div class="card" style="padding:14px;">
    <strong>Filter:</strong>
    <a href="inventory.php"             class="btn btn-sm <?= !$filter?'btn-primary':'btn-secondary' ?>" style="margin:3px">All</a>
    <a href="inventory.php?filter=good" class="btn btn-sm <?= $filter==='good'?'btn-success':'btn-secondary' ?>" style="margin:3px">✅ Good</a>
    <a href="inventory.php?filter=low"  class="btn btn-sm <?= $filter==='low'?'btn-warning':'btn-secondary' ?>" style="margin:3px">⚠️ Low</a>
    <a href="inventory.php?filter=out"  class="btn btn-sm <?= $filter==='out'?'btn-danger':'btn-secondary' ?>" style="margin:3px">❌ Out</a>
</div>

<div class="card">
    <div class="table-wrapper">
        <table>
            <thead><tr><th>#</th><th>Product</th><th>Category</th><th>Price</th><th>Baker</th><th>Stock</th><th>Status</th><th>Update</th></tr></thead>
            <tbody>
                <?php while ($p = $products->fetch_assoc()): ?>
                <tr>
                    <td><?= $p['id'] ?></td>
                    <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
                    <td><?= htmlspecialchars($p['category']) ?></td>
                    <td>Rs. <?= number_format($p['price'], 2) ?></td>
                    <td><?= $p['baker_name'] ? htmlspecialchars($p['baker_name']) : '<em>Admin</em>' ?></td>
                    <td><span class="badge badge-<?= $p['stock_quantity']===0?'danger':($p['stock_quantity']<5?'warning':'success') ?>"><?= $p['stock_quantity'] ?> units</span></td>
                    <td><span class="badge badge-<?= $p['status']==='available'?'success':'danger' ?>"><?= ucfirst(str_replace('_',' ',$p['status'])) ?></span></td>
                    <td>
                        <form method="POST" style="display:flex;gap:6px;align-items:center;">
                            <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                            <input type="number" name="stock_quantity" value="<?= $p['stock_quantity'] ?>" min="0" class="qty-input" style="width:70px">
                            <button type="submit" class="btn btn-success btn-sm">💾</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
