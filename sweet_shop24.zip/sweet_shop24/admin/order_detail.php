<?php
require_once '../includes/config.php';
requireRole('admin', '../login.php');
$basePath = '../';
$id    = (int)($_GET['id'] ?? 0);
$order = $conn->query("SELECT o.*, u.full_name, u.email FROM orders o JOIN users u ON o.customer_id = u.id WHERE o.id=$id")->fetch_assoc();
if (!$order) { setFlash('error','Order not found.'); redirect('orders.php'); }
$pageTitle = 'Order #'.$id;
$items = $conn->query("SELECT oi.*, p.name, p.category FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id=$id");
include '../includes/header.php';
?>

<div class="flex-between mb-20">
    <h1 class="page-title" style="margin:0">Order #<?= $id ?> Details</h1>
    <a href="orders.php" class="btn btn-secondary">← Back</a>
</div>

<div class="grid-2">
    <div class="card">
        <h3>Customer Info</h3>
        <p><strong>Name:</strong> <?= htmlspecialchars($order['full_name']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($order['email']) ?></p>
        <p><strong>Date:</strong> <?= date('d M Y H:i', strtotime($order['created_at'])) ?></p>
    </div>
    <div class="card">
        <h3>Order Summary</h3>
        <p><strong>Status:</strong> <span class="badge badge-warning"><?= ucfirst($order['status']) ?></span></p>
        <p><strong>Total:</strong> <strong style="color:#c0392b;font-size:1.3rem">Rs. <?= number_format($order['total_amount'], 2) ?></strong></p>
        <form method="POST" action="orders.php" style="margin-top:12px">
            <input type="hidden" name="order_id" value="<?= $id ?>">
            <div class="form-group">
                <label>Update Status</label>
                <select name="status">
                    <?php foreach (['pending','confirmed','preparing','ready','delivered','cancelled'] as $s): ?>
                        <option value="<?= $s ?>" <?= $order['status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary btn-sm">Update</button>
        </form>
    </div>
</div>

<div class="card">
    <h3>Items Ordered</h3>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
            <tbody>
                <?php while ($item = $items->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($item['name']) ?></td>
                    <td><?= htmlspecialchars($item['category']) ?></td>
                    <td>Rs. <?= number_format($item['price'], 2) ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td>Rs. <?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="4" style="text-align:right;font-weight:700;padding:12px 16px;">Total:</td>
                    <td style="font-weight:700;color:#c0392b;font-size:1.1rem">Rs. <?= number_format($order['total_amount'], 2) ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
