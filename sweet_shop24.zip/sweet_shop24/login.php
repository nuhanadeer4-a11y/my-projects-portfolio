<?php
require_once 'includes/config.php';
$pageTitle = 'Login';
$cssPath = '';
$basePath = '';
$homePath = 'index.php';

if (isLoggedIn()) {
    if (hasRole('admin'))    redirect('admin/dashboard.php');
    if (hasRole('baker'))    redirect('baker/dashboard.php');
    if (hasRole('customer')) redirect('customer/shop.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = clean($conn, $_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        if ($stmt === false) { die("Query error: " . $conn->error); }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user   = $result->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            if ($user['status'] === 'suspended') {
                $error = 'Your account has been suspended.';
            } elseif ($user['status'] === 'pending') {
                $error = 'Your baker account is pending admin approval.';
            } else {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name']    = $user['full_name'];
                $_SESSION['email']   = $user['email'];
                $_SESSION['role']    = $user['role'];
                setFlash('success', 'Welcome back, ' . $user['full_name'] . '!');
                if ($user['role'] === 'admin')    redirect('admin/dashboard.php');
                if ($user['role'] === 'baker')    redirect('baker/dashboard.php');
                if ($user['role'] === 'customer') redirect('customer/shop.php');
            }
        } else {
            $error = 'Incorrect email or password.';
        }
    }
}

include 'includes/header.php';
?>

<div class="auth-wrapper">
    <div class="auth-box">
        <h2>🍰 Sign In</h2>
        <p class="subtitle">Welcome back! Please log in to continue.</p>

        <?php if ($error): ?>
            <div class="flash flash-error" style="margin-bottom:16px;border-radius:8px;">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email Address</label>
                <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                       placeholder="you@example.com" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" placeholder="Your password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block" style="padding:13px;">
                <i class="fas fa-sign-in-alt"></i> Log In
            </button>
        </form>

        <div class="auth-footer">
            Don't have an account? <a href="register.php">Register here</a>
        </div>

        <!--<div style="margin-top:20px;padding:14px;background:#fff8f8;border-radius:8px;font-size:.8rem;color:#888;">
            <strong>Demo accounts (password: password)</strong><br>
            Admin: admin@sweetshop.com<br>
            
            Customer: customer@sweetshop.com
        </div>
    </div>
</div>


