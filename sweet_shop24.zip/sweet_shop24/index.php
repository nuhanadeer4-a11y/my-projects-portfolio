<?php
// index.php — Public Home Page
require_once 'includes/config.php';
$pageTitle = 'Home';
$cssPath = '';
$homePath = 'index.php';
$basePath = '';

// If already logged in, redirect to correct dashboard
if (isLoggedIn()) {
    if (hasRole('admin'))    redirect('admin/dashboard.php');
    if (hasRole('baker'))    redirect('baker/dashboard.php');
    if (hasRole('customer')) redirect('customer/shop.php');
}

// Fetch featured products
$featured = $conn->query("SELECT * FROM products WHERE status='available' ORDER BY id DESC LIMIT 6");

include 'includes/header.php';
?>

<!-- HERO SECTION -->
<div class="hero">
    <h1>🍰 Welcome to Sweet Shop</h1>
    <p>Handcrafted sweets & baked goods made with love</p>
    <div class="hero-buttons">
        <a href="register.php" class="btn btn-white">🛍️ Get Started</a>
        <a href="login.php" class="btn btn-outline-white">🔑 Login</a>
    </div>
</div>

<!-- HOW IT WORKS -->
<!--<section style="margin-bottom:50px;">
    <h2 class="page-title" style="text-align:center;">How It Works</h2>
    <div class="grid-3">
        <div class="card text-center" style="padding:30px;">
            <div style="font-size:3.5rem;margin-bottom:14px;">🛍️</div>
            <h3 style="margin-bottom:10px;color:#c0392b;">Browse & Order</h3>
            <p class="text-muted">Browse our wide selection of handcrafted sweets and add your favourites to cart</p>
        </div>
        <div class="card text-center" style="padding:30px;">
            <div style="font-size:3.5rem;margin-bottom:14px;">👨‍🍳</div>
            <h3 style="margin-bottom:10px;color:#c0392b;">Home Bakers</h3>
            <p class="text-muted">Talented home bakers list their products after admin approval to ensure quality</p>
        </div>
        <div class="card text-center" style="padding:30px;">
            <div style="font-size:3.5rem;margin-bottom:14px;">🚀</div>
            <h3 style="margin-bottom:10px;color:#c0392b;">Fast Delivery</h3>
            <p class="text-muted">Get your favourite sweets delivered fresh to your doorstep quickly</p>
        </div>
    </div>
</section>-->


<!-- ABOUT US -->
<section style="margin-bottom:50px;">
    <h2 class="page-title" style="text-align:center;">About Us</h2>
    <div class="card" style="padding:40px;">
        <div class="grid-2" style="align-items:center;gap:40px;">
            <div>
                <h3 style="font-size:1.6rem;color:#c0392b;margin-bottom:16px;">
                    🍰 Our Sweet Story
                </h3>
                <p style="line-height:1.8;color:#555;margin-bottom:14px;">
                    Welcome to <strong>Sweet Shop</strong> — your one-stop destination for
                    delicious handcrafted sweets and baked goods made with love by talented
                    home bakers in your community.
                    We connect passionate home bakers with sweet lovers like you.
                    Every product is carefully reviewed and approved by our admin team
                    to ensure the highest quality standards.
                </p>
                <p style="line-height:1.8;color:#555;">
                    From rich chocolate cakes to delicate French macarons,
                    we have something special for every sweet tooth!
                </p><div>
                <div class="grid-2" style="gap:16px;">
                    <div class="stat-card">
                        <div class="stat-icon">🍰</div>
                        <div class="stat-number">50+</div>
                        <div class="stat-label">Sweet Products</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">😊</div>
                        <div class="stat-number">500+</div>
                        <div class="stat-label">Happy Customers</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">⭐</div>
                        <div class="stat-number">4.9</div>
                        <div class="stat-label">Customer Rating</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FEATURED PRODUCTS -->
<section style="margin-bottom:50px;">
    <div class="flex-between" style="margin-bottom:24px;">
        <h2 class="page-title" style="margin:0;">🍰 Featured Sweets</h2>
        <a href="login.php" class="btn btn-primary">View All Products →</a>
    </div>
    <div class="grid-3">
        <?php while ($p = $featured->fetch_assoc()): ?>
        <?php
        $categoryImages = [
            'Cakes'       => 'assets/images/41.jpg',
            'Cupcakes'    => 'assets/images/15.jpg',
            'Macarons'    => 'assets/images/39.jpg',
            'Cookies'     => 'assets/images/32.jpg',
            'Traditional' => 'assets/images/38.jpg',
            'Other'       => 'assets/images/14.jpg',
        ];
        $imgSrc = $categoryImages[$p['category']] ?? 'assets/images/1.jpg';
        ?>
        <div class="product-card">
            <img src="<?= $imgSrc ?>" alt="<?= htmlspecialchars($p['name']) ?>"
                 style="width:100%;height:160px;object-fit:cover;">
            <div class="product-info">
                <span class="category"><?= htmlspecialchars($p['category']) ?></span>
                <h3><?= htmlspecialchars($p['name']) ?></h3>
                <p class="text-muted" style="font-size:.85rem;margin:6px 0;">
                    <?= htmlspecialchars(substr($p['description'], 0, 70)) ?>...
                </p>
                <div class="price">Rs. <?= number_format($p['price'], 2) ?></div>
            </div>
            <div class="card-actions">
                <a href="login.php" class="btn btn-primary btn-sm" style="width:100%;text-align:center;">
                    🛒 Login to Order
                </a>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</section>


                
           

<!-- WHY CHOOSE US -->
<section style="margin-bottom:50px;">
    <h2 class="page-title" style="text-align:center;">Why Choose Us?</h2>
    <div class="grid-4">
        <div class="card text-center" style="padding:24px;">
            <div style="font-size:2.5rem;margin-bottom:10px;">🌿</div>
            <h4 style="color:#c0392b;margin-bottom:8px;">Fresh Ingredients</h4>
            <p class="text-muted" style="font-size:.85rem;">All products made with fresh natural ingredients</p>
        </div>
        <div class="card text-center" style="padding:24px;">
            <div style="font-size:2.5rem;margin-bottom:10px;">✅</div>
            <h4 style="color:#c0392b;margin-bottom:8px;">Quality Checked</h4>
            <p class="text-muted" style="font-size:.85rem;">Every product approved by our admin team</p>
        </div>
        <div class="card text-center" style="padding:24px;">
            <div style="font-size:2.5rem;margin-bottom:10px;">💰</div>
            <h4 style="color:#c0392b;margin-bottom:8px;">Best Prices</h4>
            <p class="text-muted" style="font-size:.85rem;">Affordable prices direct from home bakers</p>
        </div>
        <div class="card text-center" style="padding:24px;">
            <div style="font-size:2.5rem;margin-bottom:10px;">🚚</div>
            <h4 style="color:#c0392b;margin-bottom:8px;">Fast Delivery</h4>
            <p class="text-muted" style="font-size:.85rem;">Quick and reliable delivery to your door</p>
        </div>
    </div>
</section>


                   
       
<?php include 'includes/footer.php'; ?>
