-- ============================================================
--  Sweet Shop Management System - Database
--  Run this in phpMyAdmin to set up the database
-- ============================================================

CREATE DATABASE IF NOT EXISTS sweet_shop;
USE sweet_shop;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('customer', 'admin', 'baker') NOT NULL DEFAULT 'customer',
    status ENUM('active', 'pending', 'suspended') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    category VARCHAR(50),
    image VARCHAR(255) DEFAULT 'default.jpg',
    baker_id INT,
    status ENUM('available', 'out_of_stock', 'pending_approval') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (baker_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(id)
);

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Default admin (password: password)
INSERT INTO users (full_name, email, password, role, status) VALUES
('Admin User', 'admin@sweetshop.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active');

-- Sample baker (password: password)
INSERT INTO users (full_name, email, password, role, status) VALUES
('Baker Mary', 'baker@sweetshop.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'baker', 'active');

-- Sample customer (password: password)
INSERT INTO users (full_name, email, password, role, status) VALUES
('John Customer', 'customer@sweetshop.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'active');

-- Sample products
INSERT INTO products (name, description, price, stock_quantity, category, baker_id, status) VALUES
('Chocolate Cake', 'Rich dark chocolate layered cake', 1500.00, 10, 'Cakes', 2, 'available'),
('Strawberry Cupcakes', 'Fresh strawberry cream cupcakes (pack of 6)', 850.00, 25, 'Cupcakes', 2, 'available'),
('Vanilla Macarons', 'French style vanilla macarons (pack of 12)', 1200.00, 15, 'Macarons', 2, 'available'),
('Honey Baklava', 'Traditional honey and pistachio baklava', 999.00, 20, 'Traditional', 2, 'available'),
('Lemon Drizzle', 'Zesty lemon drizzle loaf cake', 1100.00, 8, 'Cakes', 2, 'available'),
('Red Velvet Cake', 'Classic red velvet with cream cheese frosting', 1750.00, 5, 'Cakes', 2, 'available');

-- ============================================================
-- Demo accounts password is: password
-- Admin:    admin@sweetshop.com
-- Baker:    baker@sweetshop.com
-- Customer: customer@sweetshop.com
-- ============================================================
