<?php
// includes/header.php — Shared top navigation
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?> <?= isset($pageTitle) ? '— '.$pageTitle : '' ?></title>
    <link rel="stylesheet" href="<?= $cssPath ?? '../' ?>assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<nav class="navbar">
    <div class="nav-brand">
        <a href="<?= $homePath ?? '../index.php' ?>">🍰 <?= SITE_NAME ?></a>
    </div>
    <ul class="nav-links">

        <!-- ALWAYS VISIBLE FOR EVERYONE -->
        <li><a href="<?= $basePath ?? '../' ?>index.php"><i class="fas fa-home"></i> Home</a></li>
        <li><a href="<?= $basePath ?? '../' ?>customer/shop.php"><i class="fas fa-store"></i> Shop</a></li>

        <?php if (isLoggedIn()): ?>
            <!-- LOGGED IN USER INFO -->
            <li><span class="welcome-text">Hello, <?= htmlspecialchars($_SESSION['name']) ?> (<?= $_SESSION['role'] ?>)</span></li>

            <?php if (hasRole('customer')): ?>
                <!-- CUSTOMER MENU -->
                <li><a href="<?= $basePath ?? '../' ?>customer/cart.php"><i class="fas fa-shopping-cart"></i> Cart</a></li>
                <li><a href="<?= $basePath ?? '../' ?>customer/orders.php"><i class="fas fa-box"></i> My Orders</a></li>

            <?php elseif (hasRole('admin')): ?>
                <!-- ADMIN MENU -->
                <li><a href="<?= $basePath ?? '../' ?>admin/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="<?= $basePath ?? '../' ?>admin/products.php"><i class="fas fa-candy-cane"></i> Products</a></li>
                <li><a href="<?= $basePath ?? '../' ?>admin/orders.php"><i class="fas fa-list"></i> Orders</a></li>
                <li><a href="<?= $basePath ?? '../' ?>admin/users.php"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="<?= $basePath ?? '../' ?>admin/inventory.php"><i class="fas fa-boxes"></i> Inventory</a></li>
                
            <?php elseif (hasRole('baker')): ?>
                <!-- BAKER MENU -->
                <li><a href="<?= $basePath ?? '../' ?>baker/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="<?= $basePath ?? '../' ?>baker/my_products.php"><i class="fas fa-bread-slice"></i> My Products</a></li>
                <li><a href="<?= $basePath ?? '../' ?>baker/add_product.php"><i class="fas fa-plus"></i> Add Product</a></li>

            <?php endif; ?>

            <!-- LOGOUT FOR ALL LOGGED IN USERS -->
            <li><a href="<?= $basePath ?? '../' ?>logout.php" class="btn-logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>

        <?php else: ?>
            <!-- NOT LOGGED IN -->
            <li><a href="<?= $basePath ?? '../' ?>login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
            <li><a href="<?= $basePath ?? '../' ?>register.php"><i class="fas fa-user-plus"></i> Register</a></li>

        <?php endif; ?>

    </ul>
</nav>

<?php if ($flash): ?>
<div class="flash flash-<?= $flash['type'] ?>">
    <?= htmlspecialchars($flash['message']) ?>
    <button onclick="this.parentElement.remove()">✕</button>
</div>
<?php endif; ?>

<div class="container">
