<?php // includes/footer.php ?>

</div><!-- /.container -->

<footer class="site-footer">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:20px;max-width:1200px;margin:0 auto;padding:0 20px;">
        <div>
            <h3 style="color:#fff;margin-bottom:6px;">🍰 Sweet Shop</h3>
            <p>Handcrafted sweets made with love</p>
        </div>
        <div>
            <p><i class="fas fa-map-marker-alt"></i> 123 Sweet Street, Colombo, Sri Lanka</p>
            <p><i class="fas fa-phone"></i> +94 77 123 4567</p>
            <p><i class="fas fa-envelope"></i> info@sweetshop.com</p>
        </div>
        <div>
            <p><strong style="color:#fff;">Opening Hours</strong></p>
            <p>Mon - Sat: 8:00 AM - 8:00 PM</p>
            <p>Sunday: 10:00 AM - 6:00 PM</p>
        </div>
    </div>
    <div style="border-top:1px solid #444;margin-top:20px;padding-top:16px;text-align:center;">
        <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?> </p>
    </div>
</footer>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</body>
</html>
