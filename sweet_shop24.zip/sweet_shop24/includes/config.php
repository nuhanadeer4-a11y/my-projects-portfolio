<?php
// includes/config.php — Database connection

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'sweet_shop1');
define('SITE_NAME', 'sweet_shop');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("
    <div style='font-family:sans-serif;padding:40px;background:#fff3cd;border:1px solid #ffc107;margin:20px;border-radius:8px;'>
        <h2>⚠️ Database Connection Error</h2>
        <p>Could not connect to MySQL. Please check:</p>
        <ul>
            <li>XAMPP is running (Apache + MySQL)</li>
            <li>DB_USER and DB_PASS in includes/config.php</li>
            <li>You have imported database.sql in phpMyAdmin</li>
        </ul>
        <p><strong>Error:</strong> " . $conn->connect_error . "</p>
    </div>");
}

$conn->set_charset("utf8");

function redirect($url) {
    header("Location: $url");
    exit();
}

function clean($conn, $data) {
    return $conn->real_escape_string(htmlspecialchars(strip_tags(trim($data))));
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function hasRole($role) {
    return isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

function requireLogin($redirectTo = '../index.php') {
    if (!isLoggedIn()) {
        redirect($redirectTo);
    }
}

function requireRole($role, $redirectTo = '../index.php') {
    requireLogin($redirectTo);
    if (!hasRole($role)) {
        redirect($redirectTo);
    }
}

function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

// RUPEES currency
function formatPrice($price) {
    return 'Rs. ' . number_format($price, 2);
}
?>
