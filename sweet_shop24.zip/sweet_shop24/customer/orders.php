<?php
require_once '../includes/config.php';
requireRole('customer', '../login.php');
$pageTitle = 'My Orders';
$basePath  = '../';
$uid = $_SESSION['user_id'];

$orders = $conn->query("SELECT * FROM orders WHERE customer_id=$uid ORDER BY created_at DESC");

include '../includes/header.php';
?>

<h1 class="page-title">📦 My Orders</h1>

<?php if ($orders->num_rows === 0): ?>
    <div class="empty-state">
        <div class="empty-icon">📦</div>
        <p>You haven't placed any orders yet.</p>
        <a href="shop.php" class="btn btn-primary mt-10">Start Shopping</a>
    </div>
<?php else: ?>

<?php while ($order = $orders->fetch_assoc()): ?>
<?php
$badgeMap = ['pending'=>'warning','confirmed'=>'info','preparing'=>'info','ready'=>'success','delivered'=>'success','cancelled'=>'danger'];
$b = $badgeMap[$order['status']] ?? 'secondary';
?>
<div class="card" style="margin-bottom:20px">
    <div class="flex-between" style="margin-bottom:12px">
        <div>
            <strong>Order #<?= $order['id'] ?></strong>
            <span class="text-muted" style="margin-left:12px;font-size:.85rem">
                <?= date('d M Y H:i', strtotime($order['created_at'])) ?>
            </span>
        </div>
        <span class="badge badge-<?= $b ?>"><?= ucfirst($order['status']) ?></span>
    </div>

    <?php
    $items = $conn->query("SELECT oi.*, p.name, p.category FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id={$order['id']}");
    ?>
    <div class="table-wrapper">
        <table style="font-size:.88rem">
            <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
            <tbody>
                <?php while ($item = $items->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($item['name']) ?></td>
                    <td><?= htmlspecialchars($item['category']) ?></td>
                    <td>Rs. <?= number_format($item['price'], 2) ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td>Rs. <?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <div class="cart-total" style="font-size:1.1rem">Total: Rs. <?= number_format($order['total_amount'], 2) ?></div>

    <!-- Order Progress -->
    <?php $steps = ['pending','confirmed','preparing','ready','delivered']; $current = array_search($order['status'], $steps); ?>
    <div style="margin-top:16px;display:flex;align-items:center;flex-wrap:wrap">
        <?php foreach ($steps as $i => $step): ?>
        <div style="flex:1;text-align:center;padding:6px 2px">
            <div style="width:26px;height:26px;border-radius:50%;margin:0 auto 4px;
                background:<?= ($current !== false && $i <= $current) ? '#27ae60' : '#e0e0e0' ?>;
                display:flex;align-items:center;justify-content:center;color:#fff;font-size:.75rem;font-weight:700">
                <?= $i+1 ?>
            </div>
            <span style="font-size:.7rem;color:<?= ($current !== false && $i <= $current) ? '#27ae60' : '#aaa' ?>">
                <?= ucfirst($step) ?>
            </span>
        </div>
        <?php if ($i < count($steps)-1): ?>
        <div style="height:2px;flex:1;background:<?= ($current !== false && $i < $current) ? '#27ae60' : '#e0e0e0' ?>"></div>
        <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>
<?php endwhile; ?>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
