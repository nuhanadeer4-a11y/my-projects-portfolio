<?php
// customer/shop.php — Browse and add to cart
require_once '../includes/config.php';
requireRole('customer', '../login.php');
$pageTitle = 'Shop';
$basePath  = '../';

// Add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $pid = (int)$_POST['product_id'];
    $qty = max(1, (int)$_POST['quantity']);
    $uid = $_SESSION['user_id'];

    $product = $conn->query("SELECT * FROM products WHERE id=$pid AND status='available'")->fetch_assoc();
    if ($product && $product['stock_quantity'] >= $qty) {
        $existing = $conn->query("SELECT * FROM cart WHERE customer_id=$uid AND product_id=$pid")->fetch_assoc();
        if ($existing) {
            $newQty = $existing['quantity'] + $qty;
            $conn->query("UPDATE cart SET quantity=$newQty WHERE id={$existing['id']}");
        } else {
            $conn->query("INSERT INTO cart (customer_id, product_id, quantity) VALUES ($uid,$pid,$qty)");
        }
        setFlash('success', htmlspecialchars($product['name']) . ' added to cart!');
    } else {
        setFlash('error', 'Product not available or not enough stock.');
    }
    redirect('shop.php');
}

// Category filter
$cat    = clean($conn, $_GET['category'] ?? '');
$search = clean($conn, $_GET['search'] ?? '');
$where  = "WHERE p.status='available'";
if ($cat)    $where .= " AND p.category='$cat'";
if ($search) $where .= " AND p.name LIKE '%$search%'";

$products = $conn->query("
    SELECT p.*, u.full_name AS baker_name
    FROM products p LEFT JOIN users u ON p.baker_id = u.id
    $where ORDER BY p.id DESC
");

$categories = $conn->query("SELECT DISTINCT category FROM products WHERE status='available'");

include '../includes/header.php';
?>

<div class="flex-between mb-20">
    <h1 class="page-title" style="margin:0">🛍️ Shop</h1>
    <?php
    $cartCount = $conn->query("SELECT SUM(quantity) as c FROM cart WHERE customer_id=".$_SESSION['user_id'])->fetch_assoc()['c'];
    ?>
    <a href="cart.php" class="btn btn-primary">
        🛒 Cart (<?= (int)$cartCount ?> items)
    </a>
</div>

<!-- Search & Filter -->
<div class="card" style="padding:16px;margin-bottom:20px">
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
        <input type="text" name="search" placeholder="Search sweets..." value="<?= htmlspecialchars($search) ?>"
               style="flex:1;min-width:180px;padding:9px 14px;border:2px solid #e0e0e0;border-radius:8px;">
        <select name="category" style="padding:9px 14px;border:2px solid #e0e0e0;border-radius:8px;">
            <option value="">All Categories</option>
            <?php while ($c = $categories->fetch_assoc()): ?>
                <option value="<?= $c['category'] ?>" <?= $cat === $c['category'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($c['category']) ?>
                </option>
            <?php endwhile; ?>
        </select>
        <button type="submit" class="btn btn-primary">Search</button>
        <a href="shop.php" class="btn btn-secondary">Clear</a>
    </form>
</div>

<!-- Products Grid -->
<?php if ($products->num_rows === 0): ?>
    <div class="empty-state">
        <div class="empty-icon">🍰</div>
        <p>No products found. Try a different search!</p>
    </div>
<?php else: ?>
<div class="grid-3">
    <?php while ($p = $products->fetch_assoc()): ?>
    <div class="product-card">

        <!-- PRODUCT IMAGE -->
        <?php
        $categoryImages = [
            'Cakes'       => '../assets/images/41.jpg',
             'Cupcakes'    => '../assets/images/15.jpg',
             'Macarons'    => '../assets/images/39.jpg',
            'Cookies'     => '../assets/images/32.jpg',
            'Traditional' => '../assets/images/38.jpg',
             'Other'       => '../assets/images/14.jpg',
        ];
        $imgSrc = $categoryImages[$p['category']] ?? '../assets/images/1.jpg';
        ?>
        <img src="<?= $imgSrc ?>" alt="<?= htmlspecialchars($p['name']) ?>"
             style="width:100%;height:160px;object-fit:cover;">

        <div class="product-info">
            <span class="category"><?= htmlspecialchars($p['category']) ?></span>
            <h3><?= htmlspecialchars($p['name']) ?></h3>
            <p style="font-size:.84rem;color:#777;margin:6px 0">
                <?= htmlspecialchars(substr($p['description'], 0, 80)) ?>...
            </p>
            <div class="price"><?= formatPrice($p['price']) ?></div>
            <?php if ($p['stock_quantity'] > 0): ?>
                <div class="stock <?= $p['stock_quantity'] < 5 ? 'low' : '' ?>">
                    <?= $p['stock_quantity'] < 5 ? '⚠️ Only' : '✅' ?> <?= $p['stock_quantity'] ?> left
                </div>
            <?php else: ?>
                <div class="stock out">❌ Out of stock</div>
            <?php endif; ?>
            <?php if ($p['baker_name']): ?>
                <div style="font-size:.78rem;color:#aaa;margin-top:4px">
                    By <?= htmlspecialchars($p['baker_name']) ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="card-actions">
            <?php if ($p['stock_quantity'] > 0): ?>
            <form method="POST" style="display:flex;gap:6px;width:100%">
                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                <input type="number" name="quantity" value="1" min="1"
                       max="<?= $p['stock_quantity'] ?>" class="qty-input">
                <button type="submit" name="add_to_cart" class="btn btn-primary btn-sm" style="flex:1">
                    🛒 Add to Cart
                </button>
            </form>
            <?php else: ?>
                <button class="btn btn-secondary btn-sm" disabled>Out of Stock</button>
            <?php endif; ?>
        </div>

    </div>
    <?php endwhile; ?>
</div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
