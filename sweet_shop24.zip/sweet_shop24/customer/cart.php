<?php
// customer/cart.php — View and manage cart, place order
require_once '../includes/config.php';
requireRole('customer', '../login.php');
$pageTitle = 'My Cart';
$basePath  = '../';
$uid = $_SESSION['user_id'];

// Remove item
if (isset($_GET['remove'])) {
    $cid = (int)$_GET['remove'];
    $conn->query("DELETE FROM cart WHERE id=$cid AND customer_id=$uid");
    setFlash('success', 'Item removed from cart.');
    redirect('cart.php');
}

// Update quantity
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
    foreach ($_POST['quantities'] as $cid => $qty) {
        $cid = (int)$cid;
        $qty = max(1, (int)$qty);
        $conn->query("UPDATE cart SET quantity=$qty WHERE id=$cid AND customer_id=$uid");
    }
    setFlash('success', 'Cart updated.');
    redirect('cart.php');
}

// Place order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $cartItems = $conn->query("
        SELECT c.*, p.price, p.stock_quantity, p.name
        FROM cart c JOIN products p ON c.product_id = p.id
        WHERE c.customer_id=$uid
    ");

    if ($cartItems->num_rows === 0) {
        setFlash('error', 'Your cart is empty.');
        redirect('cart.php');
    }

    $items = [];
    $total = 0;
    $stockOk = true;

    while ($item = $cartItems->fetch_assoc()) {
        if ($item['quantity'] > $item['stock_quantity']) {
            setFlash('error', $item['name'] . ' does not have enough stock.');
            $stockOk = false;
            break;
        }
        $total += $item['price'] * $item['quantity'];
        $items[] = $item;
    }

    if ($stockOk && !empty($items)) {
        $conn->query("INSERT INTO orders (customer_id, total_amount) VALUES ($uid, $total)");
        $orderId = $conn->insert_id;

        foreach ($items as $item) {
            $conn->query("INSERT INTO order_items (order_id, product_id, quantity, price)
                VALUES ($orderId, {$item['product_id']}, {$item['quantity']}, {$item['price']})");
            $newStock = $item['stock_quantity'] - $item['quantity'];
            $status   = $newStock > 0 ? 'available' : 'out_of_stock';
            $conn->query("UPDATE products SET stock_quantity=$newStock, status='$status'
                WHERE id={$item['product_id']}");
        }

        $conn->query("DELETE FROM cart WHERE customer_id=$uid");
        setFlash('success', "Order #$orderId placed successfully! 🎉");
        redirect('orders.php');
    }
}

// Fetch cart
$cartItems = $conn->query("
    SELECT c.id AS cart_id, c.quantity, p.id AS product_id,
           p.name, p.price, p.category, p.stock_quantity
    FROM cart c JOIN products p ON c.product_id = p.id
    WHERE c.customer_id=$uid
");
$total = 0;
$allItems = [];
while ($row = $cartItems->fetch_assoc()) {
    $total += $row['price'] * $row['quantity'];
    $allItems[] = $row;
}

include '../includes/header.php';
?>

<h1 class="page-title">🛒 My Cart</h1>

<?php if (empty($allItems)): ?>
    <div class="empty-state">
        <div class="empty-icon">🛒</div>
        <p>Your cart is empty!</p>
        <a href="shop.php" class="btn btn-primary mt-10">Browse Products</a>
    </div>
<?php else: ?>

<div class="grid-2" style="align-items:start">
    <!-- Cart Items -->
    <div>
        <form method="POST">
            <div class="card">
                <h2 style="margin-bottom:16px">Cart Items</h2>
                <?php foreach ($allItems as $item): ?>
                <div style="display:flex;justify-content:space-between;align-items:center;
                            padding:14px 0;border-bottom:1px solid #f0f0f0;">
                    <div>
                        <strong><?= htmlspecialchars($item['name']) ?></strong><br>
                        <span class="text-muted" style="font-size:.85rem">
                            <?= htmlspecialchars($item['category']) ?>
                        </span><br>
                        <span style="color:#c0392b;font-weight:700">
                            Rs. <?= number_format($item['price'], 2) ?> each
                        </span>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px">
                        <input type="number" name="quantities[<?= $item['cart_id'] ?>]"
                               value="<?= $item['quantity'] ?>" min="1"
                               max="<?= $item['stock_quantity'] ?>"
                               class="qty-input">
                        <strong>Rs. <?= number_format($item['price'] * $item['quantity'], 2) ?></strong>
                        <a href="cart.php?remove=<?= $item['cart_id'] ?>" class="btn btn-danger btn-sm"
                           onclick="return confirm('Remove this item?')">🗑️</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="submit" name="update_cart" class="btn btn-secondary" style="margin-top:10px">
                🔄 Update Cart
            </button>
        </form>
    </div>

    <!-- Order Summary -->
    <div class="cart-summary">
        <h2 style="margin-bottom:16px">Order Summary</h2>
        <?php foreach ($allItems as $item): ?>
        <div style="display:flex;justify-content:space-between;padding:6px 0;font-size:.9rem">
            <span><?= htmlspecialchars($item['name']) ?> × <?= $item['quantity'] ?></span>
            <span>Rs. <?= number_format($item['price'] * $item['quantity'], 2) ?></span>
        </div>
        <?php endforeach; ?>
        <hr style="margin:14px 0">
        <div class="cart-total">Total: Rs. <?= number_format($total, 2) ?></div>

        <form method="POST" style="margin-top:20px">
            <button type="submit" name="place_order" class="btn btn-primary btn-block"
                    style="padding:14px;font-size:1rem">
                ✅ Place Order
            </button>
        </form>
        <a href="shop.php" class="btn btn-secondary btn-block mt-10">← Continue Shopping</a>
    </div>
</div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
