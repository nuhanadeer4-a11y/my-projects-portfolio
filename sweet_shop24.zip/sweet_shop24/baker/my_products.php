<?php
require_once '../includes/config.php';
requireRole('baker', '../login.php');
$pageTitle = 'My Products';
$basePath  = '../';
$uid = $_SESSION['user_id'];

if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM products WHERE id=".(int)$_GET['delete']." AND baker_id=$uid");
    setFlash('success', 'Product deleted.'); redirect('my_products.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $pid   = (int)$_POST['product_id'];
    $name  = clean($conn, $_POST['name']);
    $desc  = clean($conn, $_POST['description']);
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock_quantity'];
    $cat   = clean($conn, $_POST['category']);
    $conn->query("UPDATE products SET name='$name', description='$desc', price=$price, stock_quantity=$stock, category='$cat', status='pending_approval' WHERE id=$pid AND baker_id=$uid");
    setFlash('info', 'Product updated and sent for re-approval.');
    redirect('my_products.php');
}

$editProduct = null;
if (isset($_GET['edit'])) {
    $editProduct = $conn->query("SELECT * FROM products WHERE id=".(int)$_GET['edit']." AND baker_id=$uid")->fetch_assoc();
}

$products = $conn->query("SELECT * FROM products WHERE baker_id=$uid ORDER BY created_at DESC");

include '../includes/header.php';
?>

<div class="flex-between mb-20">
    <h1 class="page-title" style="margin:0">🍞 My Products</h1>
    <a href="add_product.php" class="btn btn-primary">➕ Add New</a>
</div>

<?php if ($editProduct): ?>
<div class="card" style="max-width:680px;margin-bottom:24px;border-left:4px solid #e74c3c">
    <h2 style="margin-bottom:16px">✏️ Edit: <?= htmlspecialchars($editProduct['name']) ?></h2>
    <form method="POST">
        <input type="hidden" name="product_id" value="<?= $editProduct['id'] ?>">
        <div class="form-group">
            <label>Product Name</label>
            <input type="text" name="name" value="<?= htmlspecialchars($editProduct['name']) ?>" required>
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea name="description"><?= htmlspecialchars($editProduct['description']) ?></textarea>
        </div>
        <div class="form-group">
            <label>Category</label>
            <select name="category">
                <?php foreach (['Cakes','Cupcakes','Macarons','Cookies','Traditional','Other'] as $cat): ?>
                    <option <?= $editProduct['category']===$cat?'selected':'' ?>><?= $cat ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Price (Rs.)</label>
                <input type="number" name="price" step="0.01" value="<?= $editProduct['price'] ?>" required>
            </div>
            <div class="form-group">
                <label>Stock Quantity</label>
                <input type="number" name="stock_quantity" value="<?= $editProduct['stock_quantity'] ?>" required>
            </div>
        </div>
        <div style="display:flex;gap:10px">
            <button type="submit" class="btn btn-primary">💾 Save Changes</button>
            <a href="my_products.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<div class="card">
    <?php if ($products->num_rows === 0): ?>
        <div class="empty-state" style="padding:40px">
            <div class="empty-icon">🍰</div>
            <p>No products yet.</p>
            <a href="add_product.php" class="btn btn-primary mt-10">➕ Add Product</a>
        </div>
    <?php else: ?>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>#</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
                <?php while ($p = $products->fetch_assoc()): ?>
                <?php $sc = ['available'=>'success','out_of_stock'=>'danger','pending_approval'=>'warning']; ?>
                <tr>
                    <td><?= $p['id'] ?></td>
                    <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
                    <td><?= htmlspecialchars($p['category']) ?></td>
                    <td>Rs. <?= number_format($p['price'], 2) ?></td>
                    <td><span class="badge badge-<?= $p['stock_quantity']<5?'warning':'success' ?>"><?= $p['stock_quantity'] ?></span></td>
                    <td><span class="badge badge-<?= $sc[$p['status']]??'secondary' ?>"><?= ucfirst(str_replace('_',' ',$p['status'])) ?></span></td>
                    <td>
                        <a href="my_products.php?edit=<?= $p['id'] ?>" class="btn btn-warning btn-sm">✏️ Edit</a>
                        <a href="my_products.php?delete=<?= $p['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete?')">🗑️</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
