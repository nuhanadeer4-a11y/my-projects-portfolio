<?php
require_once '../includes/config.php';
requireRole('baker', '../login.php');
$pageTitle = 'Add Product';
$basePath  = '../';
$uid = $_SESSION['user_id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = clean($conn, $_POST['name']);
    $desc  = clean($conn, $_POST['description']);
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock_quantity'];
    $cat   = clean($conn, $_POST['category']);

    if (empty($name) || $price <= 0 || $stock < 0) {
        $error = 'Please fill in all required fields correctly.';
    } else {
        $conn->query("INSERT INTO products (name, description, price, stock_quantity, category, baker_id, status) VALUES ('$name','$desc',$price,$stock,'$cat',$uid,'pending_approval')");
        setFlash('success', 'Product submitted for admin approval!');
        redirect('my_products.php');
    }
}

include '../includes/header.php';
?>

<div class="flex-between mb-20">
    <h1 class="page-title" style="margin:0">➕ Add New Product</h1>
    <a href="my_products.php" class="btn btn-secondary">← My Products</a>
</div>

<div class="card" style="max-width:680px">
    <div style="background:#fff3cd;border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:.9rem">
        ℹ️ <strong>Note:</strong> New products are reviewed by admin before going live in the shop.
    </div>

    <?php if ($error): ?>
        <div class="flash flash-error" style="border-radius:8px;margin-bottom:16px"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Product Name *</label>
            <input type="text" name="name" required placeholder="e.g. Chocolate Fudge Cake" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea name="description" placeholder="Describe your product..."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
        </div>
        <div class="form-group">
            <label>Category</label>
            <select name="category">
                <?php foreach (['Cakes','Cupcakes','Macarons','Cookies','Traditional','Other'] as $cat): ?>
                    <option><?= $cat ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Price (Rs.) *</label>
                <input type="number" name="price" step="0.01" min="0.01" required placeholder="e.g. 1500.00" value="<?= htmlspecialchars($_POST['price'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Stock Quantity *</label>
                <input type="number" name="stock_quantity" min="0" required placeholder="e.g. 10" value="<?= htmlspecialchars($_POST['stock_quantity'] ?? '') ?>">
            </div>
        </div>
        <button type="submit" class="btn btn-primary" style="padding:12px 28px">📤 Submit for Approval</button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
