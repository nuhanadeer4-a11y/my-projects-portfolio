<?php
require_once '../includes/config.php';
requireRole('baker', '../login.php');
$pageTitle = 'Baker Dashboard';
$basePath  = '../';
$uid = $_SESSION['user_id'];

$myProducts      = $conn->query("SELECT COUNT(*) as c FROM products WHERE baker_id=$uid")->fetch_assoc()['c'];
$availableProducts = $conn->query("SELECT COUNT(*) as c FROM products WHERE baker_id=$uid AND status='available'")->fetch_assoc()['c'];
$pendingProducts = $conn->query("SELECT COUNT(*) as c FROM products WHERE baker_id=$uid AND status='pending_approval'")->fetch_assoc()['c'];
$myOrders        = $conn->query("SELECT COUNT(DISTINCT o.id) as c FROM orders o JOIN order_items oi ON o.id = oi.order_id JOIN products p ON oi.product_id = p.id WHERE p.baker_id=$uid")->fetch_assoc()['c'];
$products        = $conn->query("SELECT * FROM products WHERE baker_id=$uid ORDER BY created_at DESC LIMIT 5");

include '../includes/header.php';
?>

<h1 class="page-title">👨‍🍳 Baker Dashboard</h1>
<p class="text-muted" style="margin-top:-14px;margin-bottom:24px">Welcome, <?= htmlspecialchars($_SESSION['name']) ?>!</p>

<div class="grid-4" style="margin-bottom:28px">
    <div class="stat-card"><div class="stat-icon">🍰</div><div class="stat-number"><?= $myProducts ?></div><div class="stat-label">My Products</div></div>
    <div class="stat-card" style="border-top-color:#27ae60"><div class="stat-icon">✅</div><div class="stat-number" style="color:#27ae60"><?= $availableProducts ?></div><div class="stat-label">Live Products</div></div>
    <div class="stat-card" style="border-top-color:#e67e22"><div class="stat-icon">⏳</div><div class="stat-number" style="color:#e67e22"><?= $pendingProducts ?></div><div class="stat-label">Pending Approval</div></div>
    <div class="stat-card" style="border-top-color:#3498db"><div class="stat-icon">📦</div><div class="stat-number" style="color:#3498db"><?= $myOrders ?></div><div class="stat-label">Orders with My Items</div></div>
</div>

<div class="grid-2" style="margin-bottom:28px">
    <a href="add_product.php"  class="btn btn-primary" style="padding:16px;font-size:1rem;text-align:center">➕ Add New Product</a>
    <a href="my_products.php" class="btn btn-info"    style="padding:16px;font-size:1rem;text-align:center">🍞 View My Products</a>
</div>

<div class="card">
    <div class="flex-between mb-20">
        <h2>My Recent Products</h2>
        <a href="my_products.php" class="btn btn-secondary btn-sm">View All</a>
    </div>
    <?php if ($products->num_rows === 0): ?>
        <div class="empty-state" style="padding:30px">
            <div class="empty-icon">🍰</div>
            <p>No products yet.</p>
            <a href="add_product.php" class="btn btn-primary mt-10">Add Your First Product</a>
        </div>
    <?php else: ?>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>Product</th><th>Price</th><th>Stock</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
                <?php while ($p = $products->fetch_assoc()): ?>
                <?php $sc = ['available'=>'success','out_of_stock'=>'danger','pending_approval'=>'warning']; ?>
                <tr>
                    <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
                    <td>Rs. <?= number_format($p['price'], 2) ?></td>
                    <td><?= $p['stock_quantity'] ?></td>
                    <td><span class="badge badge-<?= $sc[$p['status']]??'secondary' ?>"><?= ucfirst(str_replace('_',' ',$p['status'])) ?></span></td>
                    <td><?= date('d M Y', strtotime($p['created_at'])) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
